﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GasStationTools.Modelo
{
    public class cls_p7_estacion
    {
        public string IdPemex { get; set; }
        public string CentroCostos { get; set; }
        public string ESTACION { get; set; }
        public string IP { get; set; }
        public bool EnLinea { get; set; }
        public double ComprasAVG { get; set; }

        public List<cls_cfdi_compra> obj_compras { get; set; }
        public double Precio_Compra { get; set; }

        public cls_p7_estacion()
        {
            obj_compras = new List<cls_cfdi_compra>();
        }
    }
}

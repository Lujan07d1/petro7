﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GasStationTools.Modelo
{
    public class cls_cfdi_venta
    {
        //UUID	4e365de8-6cfb-4884-afcc-b783b283394a
        //TIPO    INGRESO
        //PRECIOVENTA	20.49
        //TOTALFACTURA	409.8
        //FECHAHORATRANSACCION	2021-01-24T14:48:05
        //VOLUMEN	20
        //RFCCLIENTE PIVF860530EW2
        //NOMBRECLIENTE Fernando Daniel Pliego Viveros
        //PRODUCTO	32011.MAGNA
        //FECHAVENTA	23/01/2021
        public string Estacion { get; set; }
        public string UUID { get; set; }
        public string Tipo { get; set; }
        public string PrecioVenta { get; set; }
        public string TotalFactura { get; set; }
        public string FechaHoraTransaccion { get; set; }
        public string Volumen { get; set; }
        public string RfcCliente { get; set; }

        private string _nombreCliente;

        public string NombreCliente
        {
            get { return _nombreCliente; }
            set
            {
                if (!string.IsNullOrEmpty(value) && value.Length < 10)
                {
                    _nombreCliente = value.PadRight(10, ' ');
                }
                else if (!string.IsNullOrEmpty(value) && value.Length > 150)
                {
                    _nombreCliente = value.Substring(0, 149);
                }
                else
                {
                    _nombreCliente = value;
                }

            }
        }

        public string Producto { get; set; }
        public string ProductoRef { get; set; }
        public string FechaVenta { get; set; }
        public string PrecioCompra { get; set; }


        public cls_cfdi_venta()
        { }

        public static string LayoutHeader()
        {
            string res = "";
            StringBuilder str = new StringBuilder();
            str.Append("UUID|TIPO|PRECIOVENTA|TOTALFACTURA|FECHAHORATRANSACCION|VOLUMEN|RFCCLIENTE|NOMBRECLIENTE|PRODUCTO|FECHAVENTA");
            res = str.ToString();
            return res;
        }
        public string ToLayout()
        {
            string res = "";
            StringBuilder str = new StringBuilder();
            str.Append(UUID);
            str.Append("|");
            str.Append("INGRESO");
            str.Append("|");
            str.Append(string.IsNullOrEmpty(PrecioVenta) ? "0" : PrecioVenta.Replace(",", ""));
            str.Append("|");
            str.Append(string.IsNullOrEmpty(TotalFactura) ? "0" : TotalFactura.Replace(",", ""));
            str.Append("|");
            str.Append(string.IsNullOrEmpty(FechaHoraTransaccion) ? "0" : Convert.ToDateTime(FechaHoraTransaccion).ToString("yyyy-MM-ddTHH:mm:ss"));
            str.Append("|");
            str.Append(string.IsNullOrEmpty(Volumen) ? "0" : Volumen.Replace(",", ""));
            str.Append("|");
            str.Append(string.IsNullOrEmpty(RfcCliente) ? " " : RfcCliente);
            str.Append("|");
            str.Append(string.IsNullOrEmpty(NombreCliente) ? RfcCliente : NombreCliente);
            str.Append("|");
            str.Append(string.IsNullOrEmpty(ProductoRef) ? " " : ProductoRef); //DIESEL,MAGNA,PREMIUM
            str.Append("|");
            str.Append(string.IsNullOrEmpty(FechaHoraTransaccion) ? "0" : Convert.ToDateTime(FechaHoraTransaccion).ToString("yyyy-MM-dd"));

            res = str.ToString();
            return res;
        }

        public static string SqlHeader()
        {
            string res = "";
            StringBuilder str = new StringBuilder();
            str.Append("with facturas as (");
            res = str.ToString();
            return res;

        }

        public string SqlBody(int version)
        {
            switch (version)
            {
                case 0:
                    return InsertIntoFull();
                case 2:
                    return SimpleSelect();
                case 1:
                    return InsertIntoSelect();
                default:
                    return "";
            }
        }

        private string SimpleSelect()
        {
            string res = "";
            StringBuilder str = new StringBuilder();
            str.Append("/* " + Estacion + " */");
            str.Append("SELECT ");
            str.Append("'" + UUID + "'"); //cfdi_uuid
            str.Append(" cfdi_uuid");
            str.Append(",");
            str.Append("'I'"); //cfdi_tipo
            str.Append(" cfdi_tipo");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(FechaHoraTransaccion) ? "0" : Convert.ToDateTime(FechaHoraTransaccion).ToString("yyyyMMdd")); //cfdi_fecha
            str.Append(" cfdi_fecha");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(FechaHoraTransaccion) ? "0" : Convert.ToDateTime(FechaHoraTransaccion).ToString("HHmmss")); //cfdi_hora
            str.Append(" cfdi_hora");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(FechaHoraTransaccion) ? "0" : Convert.ToDateTime(FechaHoraTransaccion).ToString("yyyyMMdd"));  //fecha_oper
            str.Append(" fecha_oper");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(Volumen) ? "0" : Volumen.Replace(",", "")); //litros
            str.Append(" litros");
            str.Append(",");
            str.Append("''"); //num_factu
            str.Append(" num_factu");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(RfcCliente) ? "''" : "'" + RfcCliente + "'"); //nnif
            str.Append(" nnif");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(NombreCliente) ? "'" + RfcCliente + "'" : "'" + NombreCliente.Replace("'", "''") + "'"); //cfdi_nombre
            str.Append(" cfdi_nombre");
            str.Append(",");
            str.Append("''"); //cv_permisop
            str.Append(" cv_permisop");
            str.Append(",");
            str.Append("''"); //codigo_tpv
            str.Append(" codigo_tpv");
            str.Append(",");
            str.Append("0"); //numero_recep
            str.Append(" numero_recep");
            str.Append(",");
            str.Append("0"); //linea_oper
            str.Append(" linea_oper");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(PrecioCompra) ? "0" : PrecioCompra.Replace(",", "")); //precio_compra
            str.Append(" precio_compra");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(PrecioVenta) ? "0" : PrecioVenta.Replace(",", "")); //precio_venta_iva
            str.Append(" precio_venta_iva");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(PrecioVenta) ? "0" : PrecioVenta.Replace(",", "")); //precio_unitario
            str.Append(" precio_unitario");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(Producto) ? "'0'" : "'" + Producto + "'");//cfdi_producto //90,95,97
            str.Append(" cfdi_producto");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(TotalFactura) ? "0" : TotalFactura.Replace(",", "")); //cfdi_total
            str.Append(" cfdi_total");
            str.Append(",");
            str.Append("'INGRESO'"); //cfdi_tipo_sat
            str.Append(" cfdi_tipo_sat");
            str.Append(",");
            str.Append(string.IsNullOrEmpty(ProductoRef) ? "''" : "'" + ProductoRef + "'"); //reserva2 //DIESEL,MAGNA,PREMIUM
            str.Append(" reserva2");
            str.Append(",");
            str.Append("''"); //reserva3
            str.Append(" reserva3");
            str.Append(",");
            str.Append("0"); //fecha1
            str.Append(" fecha1");
            str.Append(",");
            str.Append("0"); //fecha2
            str.Append(" fecha2");
            str.Append(",");
            str.Append("0.000000"); //doble1
            str.Append(" doble1");
            str.Append(",");
            str.Append("0.000000"); //doble2
            str.Append(" doble2");
            str.Append(",");
            str.Append("0.000000"); //doble3
            str.Append(" doble3");
            str.Append(",");
            str.Append("0.000000"); //doble4
            str.Append(" doble4");
            str.Append(",");
            str.Append("''"); //reserva6
            str.Append(" reserva6");
            res = str.ToString();
            return res;
        }

        public static string SqlFooter(int version = 2)
        {
            string res = "";
            StringBuilder str = new StringBuilder();

            switch (version)
            {
                case 2:
                    str.Append("), fact_ins as(" +
                       "    INSERT INTO ppv.tpcfdi(cfdi_uuid, cfdi_tipo, cfdi_fecha, cfdi_hora, fecha_oper, litros, num_factu, nnif, cfdi_nombre, cv_permisop, codigo_tpv, numero_recep, linea_oper, precio_compra, precio_venta_iva, precio_unitario, cfdi_producto, cfdi_total, cfdi_tipo_sat, reserva2, reserva3, fecha1, fecha2, doble1, doble2, doble3, doble4, reserva6)" +
                       "SELECT * " +
                       "FROM facturas f " +
                       "where not exists( SELECT 1 FROM ppv.tpcfdi tpc " +
                       "WHERE tpc.cfdi_uuid = f.cfdi_uuid AND tpc.cfdi_tipo = f.cfdi_tipo AND tpc.nnif = f.nnif AND tpc.precio_unitario = f.precio_unitario AND tpc.cfdi_producto = f.cfdi_producto)" +
                       " RETURNING 1" +
                       " ),fact_live as (" +
                       " SELECT tpc.*FROM facturas f" +
                       " INNER JOIN ppv.tpcfdi tpc ON tpc.cfdi_uuid = f.cfdi_uuid AND tpc.cfdi_tipo = f.cfdi_tipo AND tpc.nnif = f.nnif AND tpc.precio_unitario = f.precio_unitario AND tpc.cfdi_producto = f.cfdi_producto" +
                       ")" +
                       " SELECT COUNT(*) +(SELECT COUNT(*) FROM fact_ins) AS \"Result\",inet_server_addr() AS \"IP Servidor\", (SELECT nombre_esta FROM estagas.estaser) as estacion,(SELECT num_concesion FROM estagas.estaser) as id_estacion,CASE WHEN MAX(_ts) IS NULL THEN CAST(now() as timestamp) ELSE MAX(_ts) END" +
                       " FROM fact_live; ");
                    res = str.ToString();
                    return res;
                case 1:
       //             return " SELECT COUNT(*) AS \"Result\",inet_server_addr() AS \"IP Servidor\",(SELECT nombre_esta FROM estagas.estaser) as estacion,(SELECT num_concesion FROM estagas.estaser) as id_estacion,max(_ts) fecha_ultima_migracion   FROM ppv.tpcfdi WHERE cfdi_tipo = '" + ParametrosGenerales.CfdiTipoVenta + "' AND cfdi_fecha >= '" + ParametrosGenerales.CfdiFechaIni + "' AND cfdi_fecha <= '" + ParametrosGenerales.CfdiFechaFin + "' ;";
                default:
                    return "";
            }

        }




        private string InsertIntoSelect()
        {
            string res = "";
            StringBuilder str = new StringBuilder();
            str.Append("/* " + Estacion + " */");
            str.Append("INSERT INTO ppv.tpcfdi (cfdi_uuid, cfdi_tipo, cfdi_fecha, cfdi_hora, fecha_oper, litros, num_factu, nnif, cfdi_nombre," +
                "cv_permisop, codigo_tpv, numero_recep, linea_oper, precio_compra, precio_venta_iva, precio_unitario, cfdi_producto, cfdi_total, cfdi_tipo_sat," +
                " reserva2, reserva3, fecha1, fecha2, doble1, doble2, doble3, doble4, reserva6) SELECT ");
            str.Append("'" + UUID + "'"); //cfdi_uuid
            str.Append(",");
            str.Append("'I'"); //cfdi_tipo
            str.Append(",");
            str.Append(string.IsNullOrEmpty(FechaHoraTransaccion) ? "0" : Convert.ToDateTime(FechaHoraTransaccion).ToString("yyyyMMdd")); //cfdi_fecha
            str.Append(",");
            str.Append(string.IsNullOrEmpty(FechaHoraTransaccion) ? "0" : Convert.ToDateTime(FechaHoraTransaccion).ToString("HHmmss")); //cfdi_hora
            str.Append(",");
            str.Append(string.IsNullOrEmpty(FechaHoraTransaccion) ? "0" : Convert.ToDateTime(FechaHoraTransaccion).ToString("yyyyMMdd"));  //fecha_oper
            str.Append(",");
            str.Append(string.IsNullOrEmpty(Volumen) ? "0" : Volumen.Replace(",", "")); //litros
            str.Append(",");
            str.Append("''"); //num_factu
            str.Append(",");
            str.Append(string.IsNullOrEmpty(RfcCliente) ? "''" : "'" + RfcCliente + "'"); //nnif
            str.Append(",");
            str.Append(string.IsNullOrEmpty(NombreCliente) ? "'" + RfcCliente + "'" : "'" + NombreCliente.Replace("'", "''") + "'"); //cfdi_nombre
            str.Append(",");
            str.Append("''"); //cv_permisop
            str.Append(",");
            str.Append("''"); //codigo_tpv
            str.Append(",");
            str.Append("0"); //numero_recep
            str.Append(",");
            str.Append("0"); //linea_oper
            str.Append(",");
            str.Append(string.IsNullOrEmpty(PrecioCompra) ? "0" : PrecioCompra.Replace(",", "")); //precio_compra
            str.Append(",");
            str.Append(string.IsNullOrEmpty(PrecioVenta) ? "0" : PrecioVenta.Replace(",", "")); //precio_venta_iva
            str.Append(",");
            str.Append(string.IsNullOrEmpty(PrecioVenta) ? "0" : PrecioVenta.Replace(",", "")); //precio_unitario
            str.Append(",");
            str.Append(string.IsNullOrEmpty(Producto) ? "0" : Producto);//cfdi_producto //90,95,97
            str.Append(",");
            str.Append(string.IsNullOrEmpty(TotalFactura) ? "0" : TotalFactura.Replace(",", "")); //cfdi_total
            str.Append(",");
            str.Append("'INGRESO'"); //cfdi_tipo_sat
            str.Append(",");
            str.Append(string.IsNullOrEmpty(ProductoRef) ? "''" : "'" + ProductoRef + "'"); //reserva2 //DIESEL,MAGNA,PREMIUM
            str.Append(",");
            str.Append("''"); //reserva3
            str.Append(",");
            str.Append("0"); //fecha1
            str.Append(",");
            str.Append("0"); //fecha2
            str.Append(",");
            str.Append("0.000000"); //doble1
            str.Append(",");
            str.Append("0.000000"); //doble2
            str.Append(",");
            str.Append("0.000000"); //doble3
            str.Append(",");
            str.Append("0.000000"); //doble4
            str.Append(",");
            str.Append("''"); //reserva6
            str.Append("where not exists (SELECT 1 FROM ppv.tpcfdi WHERE ");
            str.Append("cfdi_uuid = " + "'" + UUID + "'"); //cfdi_uuid
            str.Append(" AND ");
            str.Append("cfdi_tipo =  'I'");
            str.Append(" AND ");
            str.Append("nnif =  " + (string.IsNullOrEmpty(RfcCliente) ? "''" : "'" + RfcCliente + "'"));
            str.Append(" AND ");
            str.Append("precio_unitario = " + (string.IsNullOrEmpty(PrecioVenta) ? "0" : PrecioVenta.Replace(",", "")));
            str.Append(" AND ");
            str.Append("cfdi_producto = " + (string.IsNullOrEmpty(Producto) ? "'0'" : "'" + Producto + "'"));
            str.Append(");");
            res = str.ToString();
            return res;
        }

        private string InsertIntoFull()
        {
            string res = "";
            StringBuilder str = new StringBuilder();
            str.Append("/* " + Estacion + " */");
            str.Append("INSERT INTO ppv.tpcfdi (_id, _ts, cfdi_uuid, cfdi_tipo, cfdi_fecha, cfdi_hora, fecha_oper, litros, num_factu, nnif, cfdi_nombre," +
                "cv_permisop, codigo_tpv, numero_recep, linea_oper, precio_compra, precio_venta_iva, precio_unitario, cfdi_producto, cfdi_total, cfdi_tipo_sat," +
                " reserva2, reserva3, fecha1, fecha2, doble1, doble2, doble3, doble4, reserva6) VALUES ( ");
            str.Append("default"); //_id
            str.Append(",");
            str.Append("default"); //_ts
            str.Append(",");
            str.Append("'" + UUID + "'"); //cfdi_uuid
            str.Append(",");
            str.Append("'I'"); //cfdi_tipo
            str.Append(",");
            str.Append(string.IsNullOrEmpty(FechaHoraTransaccion) ? "0" : Convert.ToDateTime(FechaHoraTransaccion).ToString("yyyyMMdd")); //cfdi_fecha
            str.Append(",");
            str.Append(string.IsNullOrEmpty(FechaHoraTransaccion) ? "0" : Convert.ToDateTime(FechaHoraTransaccion).ToString("HHmmss")); //cfdi_hora
            str.Append(",");
            str.Append(string.IsNullOrEmpty(FechaHoraTransaccion) ? "0" : Convert.ToDateTime(FechaHoraTransaccion).ToString("yyyyMMdd"));  //fecha_oper
            str.Append(",");
            str.Append(string.IsNullOrEmpty(Volumen) ? "0" : Volumen.Replace(",", "")); //litros
            str.Append(",");
            str.Append("''"); //num_factu
            str.Append(",");
            str.Append(string.IsNullOrEmpty(RfcCliente) ? "''" : "'" + RfcCliente + "'"); //nnif
            str.Append(",");
            str.Append(string.IsNullOrEmpty(NombreCliente) ? "'" + RfcCliente + "'" : "'" + NombreCliente.Replace("'", "''") + "'"); //cfdi_nombre
            str.Append(",");
            str.Append("''"); //cv_permisop
            str.Append(",");
            str.Append("''"); //codigo_tpv
            str.Append(",");
            str.Append("0"); //numero_recep
            str.Append(",");
            str.Append("0"); //linea_oper
            str.Append(",");
            str.Append(string.IsNullOrEmpty(PrecioCompra) ? "0" : PrecioCompra.Replace(",", "")); //precio_compra
            str.Append(",");
            str.Append(string.IsNullOrEmpty(PrecioVenta) ? "0" : PrecioVenta.Replace(",", "")); //precio_venta_iva
            str.Append(",");
            str.Append(string.IsNullOrEmpty(PrecioVenta) ? "0" : PrecioVenta.Replace(",", "")); //precio_unitario
            str.Append(",");
            str.Append(string.IsNullOrEmpty(Producto) ? "0" : Producto);//cfdi_producto //90,95,97
            str.Append(",");
            str.Append(string.IsNullOrEmpty(TotalFactura) ? "0" : TotalFactura.Replace(",", "")); //cfdi_total
            str.Append(",");
            str.Append("'INGRESO'"); //cfdi_tipo_sat
            str.Append(",");
            str.Append(string.IsNullOrEmpty(ProductoRef) ? "''" : "'" + ProductoRef + "'"); //reserva2 //DIESEL,MAGNA,PREMIUM
            str.Append(",");
            str.Append("''"); //reserva3
            str.Append(",");
            str.Append("0"); //fecha1
            str.Append(",");
            str.Append("0"); //fecha2
            str.Append(",");
            str.Append("0.000000"); //doble1
            str.Append(",");
            str.Append("0.000000"); //doble2
            str.Append(",");
            str.Append("0.000000"); //doble3
            str.Append(",");
            str.Append("0.000000"); //doble4
            str.Append(",");
            str.Append("''"); //reserva6
            str.Append(");");
            res = str.ToString();
            return res;
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GasStationTools.Logica; 

namespace GasStationTools.Modelo
{
    public class cls_cfdi_compra
    {       
        public string NUMERO_FACTURA { get; set; }
        public string CECO { get; set; }
        public Root_Supplier NUM_PROVEEDOR { get; set; }
        public DateTime FECHA { get; set; }
        public DateTime FECHA_TIMBRADO { get; set; }
        public string ALBARAN { get; set; }
        public string USER_STATUS { get; set; }
        public Double TOTAL { get; set; }
        public string TIPO_DOCUMENTO { get; set; }
        public Double PRECIO_UNITARIO { get; set; }
        public string UUID { get; set; }

        // CFDI
        public string PRODUCTO { get; set; }
        public double VOLUMEN_FACTURADO { get; set; }

        public string CODIGO_PRODUCTO { get; set; }
        public string ID_DESCARGA { get; set; }
        public string LINEA_OPER { get; set; }
        public string FECHA_OPER { get; set; }
      
        public cls_cfdi_compra()
        { }

    }
}

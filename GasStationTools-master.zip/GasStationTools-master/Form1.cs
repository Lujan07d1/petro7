﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GasStationTools.Logica;
using GasStationTools.Modelo; 
using ChoETL;

namespace GasStationTools
{
    public partial class Form1 : Form
    {
        const String myIniFile = "\\p7_automation_json.ini";

        const String SERVER_CONFIG = "config.server.json";
        const String PROCESS_CONFIG = "config.process.json";
        const String SUPPLIER_CONFIG = "config.supplier.json";
        const String SYSTEM_CONFIG = "config.system.json";

        const String CRASH_SOFTWARE = "Software";
        const String CRASH_CONFIG = "Configuración general";
        const String CRASH_PURCHASE = "Carga de Compras";
        const String CRASH_SALE = "Carga de Ventas";

        const String CRASH_JOB_PURCHASE = "Creando instrucciones de Compras para Automatización JSON";
        const String CRASH_JOB_SALE = "Creando instrucciones de Ventas para Automatización JSON";


        private bool software_crash = false;
        const bool OUTPUT_INSERT_EDS = true;
        const bool OUTPUT_SCRIPT_EDS = false;

        private cls_common_task.procesarArchivos log;
        private DataTable logProcesado;
        private cls_json_config json_config;

        private List<Root_Server> servers;
        private List<Root_Process> process;
        private List<Root_Supplier> suppliers;
        private List<Root_Config> system;

        private List<cls_p7_estacion> obj_stations = new List<cls_p7_estacion>();
        private List<cls_cfdi_compra> obj_purchases = new List<cls_cfdi_compra>();

        private string StationFile;
        private string SupplierFile;
        private string PurchaseFile;
        private string SaleFile;

        private string StationBD;
        private string SupplierBD;
        private string PurchaseBD;
        private string SaleBD;

        private DateTime BeginDate;
        private DateTime EndDate;

        private String file_log;
        private string purchase_log;
        private string sale_log;

        private IniConfiguration ini;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var myFile = Path.GetDirectoryName(Application.ExecutablePath);
            myFile += myIniFile;
            ini = new IniConfiguration(myFile);

            file_log = string.Format(@"{0}\{1}", Path.GetDirectoryName(Application.ExecutablePath), ini.generate_json_log);
            log = new cls_common_task.procesarArchivos(file_log);
            logProcesado = log.CrearTable("myLog");

            json_config = new cls_json_config();

            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", ini.generate_json_exe));
            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Inicia Configuración de Automatización");

            deserializeandDecodeConfig();
        }

        private void deserializeandDecodeConfig()
        {
            string path = "";


            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Inicia deserialización y desencriptado");

            path = string.Format(@"{0}{1}", ini.generate_json_exe_path, SYSTEM_CONFIG);
            if (!File.Exists(path))
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Error leyendo configuración de sistema...{0} ", SYSTEM_CONFIG));
                software_crash = true;
            }
            else
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Objeto sistema");
                system = json_config.DeserializeConfig(path);
            }

            path = string.Format(@"{0}{1}", ini.generate_json_exe_path, SERVER_CONFIG);
            if (!File.Exists(path))
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Error leyendo configuración de servidores...{0} ", SERVER_CONFIG));
                software_crash = true;
            }
            else
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Objeto servidores");
                servers = json_config.DeserializeServer(path);
            }

            path = string.Format(@"{0}{1}", ini.generate_json_exe_path, PROCESS_CONFIG);
            if (!File.Exists(path))
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Error leyendo configuración de procesos...{0} ", PROCESS_CONFIG));
                software_crash = true;
            }
            else
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Objeto procesos");
                process = json_config.DeserializeProcess(path);
            }

            path = string.Format(@"{0}{1}", ini.generate_json_exe_path, SUPPLIER_CONFIG);
            if (!File.Exists(path))
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Error leyendo configuración de proveedores...{0} ", SUPPLIER_CONFIG));
            }
            else
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Objeto proveedores");
                suppliers = json_config.DeserializeSupplier(path);
            }

            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Termina configuración de Objetos", ""));

            if (software_crash)
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> ", ""));
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> ERROR CARGANDO CONFIGURACION DE SISTEMA, Imposible continuar. ", ""));
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> ", ""));

                log.asignarDataTable(logProcesado);
                log.archivosProcesados();

                if (system[0].software_crash_log)
                {
                    send_log_process(logProcesado, CRASH_SOFTWARE);
                }
                return;
            }

            try
            {

                if (system[0].only_lastmonth)
                {
                    //read DateTime from Server
                    var indexOfServer = servers.IndexOf(servers.Find(p => p.platform == "SQL"));

                    using (Ado.cls_connection_sql sql = new Ado.cls_connection_sql(servers[indexOfServer].server.user_id, servers[indexOfServer].server.password, servers[indexOfServer].server.ip_address, 1433, servers[indexOfServer].server.default_database, servers[indexOfServer].server.config_plus))
                    {
                        sql.advancedSeek("select getdate() as fecha");
                        DataTable dt = sql.fillDataTable();
                        DateTime ServerDateTime = Convert.ToDateTime(dt.Rows[0]["fecha"].ToString());

                        if (ServerDateTime.Month == 1)
                        {
                            BeginDate = Convert.ToDateTime(String.Format("01/{0}/{1} 12:00:00", 12, ServerDateTime.Year - 1));
                            EndDate = Convert.ToDateTime(String.Format("{0}/{1}/{2} 12:00:00", 31, 12, ServerDateTime.Year - 1));
                        }
                        else
                        {
                            BeginDate = Convert.ToDateTime(String.Format("01/{0}/{1} 12:00:00", ServerDateTime.Month - 1, ServerDateTime.Year));
                            EndDate = Convert.ToDateTime(String.Format("{0}/{1}/{2} 12:00:00", DateTime.DaysInMonth(ServerDateTime.Year, ServerDateTime.Month - 1), ServerDateTime.Month - 1, ServerDateTime.Year));
                        }
                    }

                }
                else
                { 
                    BeginDate = Convert.ToDateTime(String.Format("01/01/{0} 12:00:00", DateTime.Now.Year));
                    EndDate = DateTime.Now;

                }

                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Periodo: <b>{0}</b> al <b>{1}</b> ", BeginDate, EndDate));

                bool ERROR_ESTACIONES = false;
                bool ERROR_PROVEEDORES = false;
                bool ERROR_COMPRAS = false;
                bool ERROR_VENTAS = false;

                // revisar origen de datos... para estaciones
                var indexOfStation = process.IndexOf(process.Find(p => p.source == "ESTACIONES"));
                ERROR_ESTACIONES = checkDataSource("Estaciones", (int)indexOfStation, out StationFile, out StationBD);
                if (!ERROR_ESTACIONES)
                {
                    var indexOfSupplier = process.IndexOf(process.Find(p => p.source == "PROVEEDORES"));
                    ERROR_PROVEEDORES = checkDataSource("Proveedores", (int)indexOfSupplier, out SupplierFile, out SupplierBD);

                    if (ERROR_PROVEEDORES)
                    {
                        logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", "Proveedores desde JSON"));
                        ERROR_PROVEEDORES = false;
                    }

                    if (!ERROR_PROVEEDORES)
                    {
                        var indexOfPurchase = process.IndexOf(process.Find(p => p.source == "COMPRAS"));
                        ERROR_COMPRAS = checkDataSource("Compras", (int)indexOfPurchase, out PurchaseFile, out PurchaseBD);
                        if (!ERROR_COMPRAS)
                        {

                            var indexOfSale = process.IndexOf(process.Find(p => p.source == "VENTAS"));
                            //ERROR_VENTAS = checkDataSource("Ventas", (int)indexOfSale, out SaleFile, out SaleBD);
                            ERROR_VENTAS = false;
                            if (!ERROR_VENTAS)
                            {
                                // Estaciones
                                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", "Procesando Estaciones"));
                                procesarEstaciones(process[indexOfStation], StationFile, StationBD);
                                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Fin Estaciones , lineas procesadas: {0} ", obj_stations.Count ));

                                // Compras
                                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", "Procesando Compras"));
                                procesarCompras(process[indexOfPurchase], PurchaseFile, PurchaseBD);
                                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Fin Compras, registros procesados: {0} ", obj_purchases.Count));

                                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", "Cálculo Estaciones/Compras"));
                                conciliaycalculaCompraxEDS(process[indexOfPurchase]);
                                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Fin Cálculo Estaciones/Compras, lineas procesadas: {0} ", obj_stations.Count * obj_purchases.Count));

                                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", "Script Estaciones/Compras"));
                                procesa_genera_salidaCompras();
                                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Fin Estaciones/Compras", ""));
                               
                            }
                            else send_log_process(logProcesado, CRASH_CONFIG);
                        }                    
                        else send_log_process(logProcesado, CRASH_CONFIG);
                    }
                    else send_log_process(logProcesado, CRASH_CONFIG);
                }


            }
            catch (Exception ex)
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Error {0} ", ex.Message));
                send_log_process(logProcesado, CRASH_CONFIG);
            }
            finally
            {

                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", "Finaliza proceso de carga"));
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", ""));

                log.asignarDataTable(logProcesado);
                log.archivosProcesados();

                if (system[0].all_activity_log)
                {
                    send_log_process(logProcesado, "Proceso de carga", "", "");
                }
            }

        }

        private bool checkDataSource(string task, int indexOf, out string output_path, out string output_bd)
        {
            string server;
            string bdd;
            string user;
            string pass;
            string plus;
            string pathfile;
            string prefix;
            string extension;

            output_bd = "";
            output_path = "";

            bool ERROR_FOUND = false;

            string columns = process[indexOf].configuration.columns;

            if (process[indexOf].configuration.datasource == "file")
            {
                pathfile = process[indexOf].configuration.path;
                prefix = process[indexOf].configuration.prefix;
                extension = process[indexOf].configuration.extension;

                if (Directory.Exists(pathfile))
                {

                    logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> El Origen de {0} es un archivo", task));

                    string file_to_process = string.Format("*{0}*.{1}", prefix, extension);
                    var files = Directory.EnumerateFiles(pathfile, file_to_process, SearchOption.AllDirectories);

                    if (files.Count() <= 0)
                    {
                        logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> No se encontró archivo de {0}", task));
                        ERROR_FOUND = true;
                    }
                    else
                    {
                        foreach (var f in files)
                        {
                            DateTime dt = File.GetLastWriteTime(f);
                            ERROR_FOUND = !validateHeaderColumn(f, columns);
                            output_path = f;

                            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Origen {0}", f));
                            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Última modificación {0}", dt.ToString()));
                        }
                    }

                }
                else ERROR_FOUND = true;

            }

            else if (process[indexOf].configuration.datasource == "query")
            {
                var indexOfServer = servers.IndexOf(servers.Find(p => p.description == process[indexOf].configuration.server_in));
                output_bd = process[indexOf].configuration.datasource;

                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Validando conexión {0}", servers[indexOfServer].platform));

                server = servers[indexOfServer].server.ip_address;
                user = servers[indexOfServer].server.user_id;
                pass = servers[indexOfServer].server.password;
                bdd = servers[indexOfServer].server.default_database;
                plus = servers[indexOfServer].server.config_plus;

                switch (servers[indexOfServer].platform)
                {
                    case "SQL":
                        {
                            try
                            {

                                using (Ado.cls_connection_sql sql = new Ado.cls_connection_sql(user, pass, server, 1433, bdd, plus))
                                {
                                    logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> conexión SQL exitosa con servidor para {0}", task));
                                }
                            }
                            catch (Exception ex)
                            {
                                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Prueba fallida: {0}", ex.Message));
                                ERROR_FOUND = true;
                            }
                            break;
                        }
                    case "ORACLE":
                        {
                            try
                            {
                                using (Ado.cls_connection_oracle sql = new Ado.cls_connection_oracle(user, pass, server, 1521, bdd, plus))
                                {
                                    logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> conexión Oracle exitosa con servidor para {0}", task));
                                }
                            }
                            catch (Exception ex)
                            {
                                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Prueba fallida: {0}", ex.Message));
                                ERROR_FOUND = true;
                            }
                            break;
                        }
                    case "POSTGRESQL":
                        {
                            try
                            {
                                using (Ado.cls_connection_postgresql sql = new Ado.cls_connection_postgresql(user, pass, server, 5432, bdd, plus))
                                {
                                    logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> conexión Postgres exitosa con servidor para {0}", task));
                                }
                            }
                            catch (Exception ex)
                            {
                                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Prueba fallida: {0}", ex.Message));
                                ERROR_FOUND = true;
                            }
                            break;
                        }
                }

            }

            return ERROR_FOUND;
        }

        private bool validateHeaderColumn(string file, string columns)
        {
            bool columnas_validas = false;
            string HEADER = File.ReadLines(file).First();

            string[] myColumns = HEADER.Split(",");
            string[] validColumns = columns.Split("|");

            for (int indexOf = 0; indexOf < validColumns.Length; indexOf++)
            {
                columnas_validas = false;
                for (int i = 0; i < myColumns.Length; i++)
                {
                    if (myColumns[i].ToUpper() == validColumns[indexOf].ToUpper())
                    {
                        columnas_validas = true;
                        break;
                    }
                }
                if (!columnas_validas)
                { 
                    logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> No se encontró la columna: {0}{1}", validColumns[indexOf].ToUpper(), columns));
                    break; 
                }
                
            }

            return columnas_validas;
        }


        private void send_log_process(DataTable log, string action, string title = "error detectado en", string msg = "Se ha detectado un error en el proceso de ")
        {
            cls_smtp_config_send_mail sendLog = new cls_smtp_config_send_mail(system[0].server, Convert.ToInt32(system[0].port), system[0].ssl, Convert.ToInt32(system[0].timeout), system[0].username, system[0].password);

            string body = string.Empty;
            string subject = String.Format("Automatización JSON, {1} {0}", action, title);

            foreach (DataRow row in log.Rows)
            {                
                body += string.Format("{0}|{1}{2}", row["Date"], row["Message"], "<br>");
            }

            body = string.Format("<b>{2}AUTOMATIZACIÓN JSON</b>{1}Revise los archivos de configuración{1}{1}{1}{0}{1}{1}<b>Equipo TI de Petro7</b>", body, "<br>", msg);
            sendLog.send_mail(system[0].notify_to, subject, body, "GasStationTools");
        }

        private void notify_log_process(DataTable log, string action, string title = "error detectado en", string msg = "Se ha detectado un error en el proceso de ")
        {
            cls_smtp_config_send_mail sendLog = new cls_smtp_config_send_mail(system[0].server, Convert.ToInt32(system[0].port), system[0].ssl, Convert.ToInt32(system[0].timeout), system[0].username, system[0].password);

            string body = string.Empty;
            string subject = String.Format("--> Automatización JSON <--, {1} {0}", action, title);

            foreach (DataRow row in log.Rows)
            {
                body += string.Format("{0}|{1}{2}", row["Date"], row["Message"], "<br>");
            }

            body = string.Format("<b>{2}AUTOMATIZACIÓN JSON 1.0</b>{1}Procesando Compras/Ventas de EDS{1}{1}{1}{0}{1}{1}<b>Equipo TI de Petro7</b>", body, "<br>", msg);
            sendLog.send_mail(system[0].notify_to, subject, body, "GasStationTools");
        }


        private void procesarEstaciones(Root_Process station, string file, string  bdd)
        {
            // Procesamos archivo CSV
            if (file.ToString() != String.Empty)
            {
                string[] validColumns = station.configuration.columns.Split("|");               

                var reader = new ChoCSVReader(file).WithFirstLineHeader();
                dynamic rec;
                while ((rec = reader.Read()) != null)
                {
                   
                    cls_p7_estacion myStation = new cls_p7_estacion();
                    for (int indexOf = 0; indexOf < validColumns.Length; indexOf++)
                    {
                        int count = 0;
                        foreach (var key in rec.Keys)
                        {
                            if (key.ToUpper() == validColumns[indexOf].ToUpper())
                            {
                                cls_common_task.SetPropertyValue(myStation, validColumns[indexOf], rec[count]);
                                break;
                            }
                            count++;
                        }
                    }
                    obj_stations.Add(myStation);
                }
            }

            if (bdd.ToString() != String.Empty)
            { 

            }        
        }


        private void procesarCompras(Root_Process purchase, string file, string bdd)
        {
            // Procesamos archivo CSV
            if (file.ToString() != String.Empty)
            {
                string[] validColumns = purchase.configuration.columns.Split("|");              

                var reader = new ChoCSVReader(file).WithFirstLineHeader();
                dynamic rec;
                while ((rec = reader.Read()) != null)
                {

                    cls_cfdi_compra myPurchase = new cls_cfdi_compra();
                    for (int indexOf = 0; indexOf < validColumns.Length; indexOf++)
                    {
                        int count = 0;
                        foreach (var key in rec.Keys)
                        {
                            if (key.ToUpper() == validColumns[indexOf].ToUpper())
                            {
                                if (key.ToUpper() == "NUM_PROVEEDOR")
                                {
                                    var indexSupplier = suppliers.IndexOf(suppliers.Find(p => p.id == Convert.ToInt32(rec[count])));
                                    myPurchase.NUM_PROVEEDOR = suppliers[indexSupplier];
                                }
                                else
                                {
                                    var value = rec[count];

                                    if (key == "FECHA" || key == "FECHA_TIMBRADO")
                                    {
                                        DateTime fecha;
                                        DateTime.TryParse(Convert.ToString(value), out fecha);
                                        cls_common_task.SetPropertyValue(myPurchase, validColumns[indexOf], fecha);

                                    } else if (key == "PRECIO_UNITARIO" || key == "TOTAL")
                                    {
                                        Double amount;
                                        Double.TryParse(Convert.ToString(value), out amount);

                                        cls_common_task.SetPropertyValue(myPurchase, validColumns[indexOf], amount);
                                    }
                                    else 
                                        cls_common_task.SetPropertyValue(myPurchase, validColumns[indexOf], value);
                                }
                                break;
                            }
                            count++;
                        }
                    }

                    // Solo procesar compras con precios menores al configurado, en este momento es de 22
                    // Que ALBARAN no esté vacio que user status in "paga" && "proceso" && tipo de documento contenga COMB
                    if (myPurchase.PRECIO_UNITARIO < system[0].max_purchase_price && myPurchase.ALBARAN != String.Empty &&
                        myPurchase.TIPO_DOCUMENTO.ToUpper().Contains("COMB") && (myPurchase.USER_STATUS.ToUpper().Contains("PAGA") ||
                        myPurchase.USER_STATUS.ToUpper().Contains("PROCESO")) && myPurchase.CECO != String.Empty)
                        // HABILITAR EN PRODUCTIVO PARA PROCESAR SOLO EM MES INMEDIATO ANTERIOR
                        //&& myPurchase.FECHA_TIMBRADO >= BeginDate && myPurchase.FECHA_TIMBRADO <= EndDate)

                        obj_purchases.Add(myPurchase);
                }
            }

            if (bdd.ToString() != String.Empty)
            {

            }
          
        }

        private void conciliaycalculaCompraxEDS(Root_Process purchase)
        {
            // Integración para cada EDS  Compras Plataforma de proveedores vs compras plataforma EDS
            foreach (cls_p7_estacion station in obj_stations)
            {
                Double importeVenta = 0;
                int transact = 0;
                var compras = obj_purchases.Where(c => c.CECO == station.ESTACION);
                foreach (cls_cfdi_compra compra in compras)
                {
                  
                    // Procesar Conciliación para cada compra

                    // sql script
                    string sqlScript = purchase.configuration.query_out.Replace(":BeginDate", String.Format("CONVERT(DATETIME,\'{0}\',103)", BeginDate.ToShortDateString()));
                    sqlScript = sqlScript.Replace(":EndDate", String.Format("CONVERT(DATETIME,\'{0}\',103)", EndDate.ToShortDateString()));

                    var indexOfServer = servers.IndexOf(servers.Find(p => p.description == purchase.configuration.server_out));

                    string sqlServerEDS = servers[indexOfServer].platform;

                    switch (sqlServerEDS)
                    {
                        case "ORACLE":
                            {
                                using (Ado.cls_connection_oracle sql = new Ado.cls_connection_oracle(servers[indexOfServer].server.user_id, servers[indexOfServer].server.password, servers[indexOfServer].server.ip_address, 1521, servers[indexOfServer].server.default_database, servers[indexOfServer].server.config_plus))
                                {
                                    sqlScript = sqlScript.Replace(":Albaran", String.Format("\'{0}\'", compra.ALBARAN));
                                    sql.advancedSeek(sqlScript);
                                    DataTable dt = sql.fillDataTable();
                                    // validate from CBOS
                                    dt.Dispose();
                                }
                                break;
                            }
                        case "SQL":
                            {
                                using (Ado.cls_connection_sql sql = new Ado.cls_connection_sql(servers[indexOfServer].server.user_id, servers[indexOfServer].server.password, servers[indexOfServer].server.ip_address, 1433, servers[indexOfServer].server.default_database, servers[indexOfServer].server.config_plus))
                                {
                                    sqlScript = sqlScript.Replace(":Albaran", String.Format("\'{0}\'", compra.ALBARAN));
                                    sql.advancedSeek(sqlScript);
                                    DataTable dt = sql.fillDataTable();

                                    foreach (DataRow row in dt.Rows)
                                    {
                                        compra.CODIGO_PRODUCTO = row["CodigoProducto"].ToString();
                                        compra.PRODUCTO = row["Producto"].ToString();
                                        compra.VOLUMEN_FACTURADO = Convert.ToDouble(row["VolumenFacturado"]);

                                        compra.ID_DESCARGA = row["IdDescarga"].ToString();
                                        compra.LINEA_OPER = row["LineaOper"].ToString();
                                       // compra.FECHA_OPER = row["FECHA_OPER"].ToString();
                                    }
                                        
                                    // validate from CBOS
                                    dt.Dispose();
                                }
                                break;
                            }
                        case "POSTGRESQL":
                            {
                                using (Ado.cls_connection_postgresql sql = new Ado.cls_connection_postgresql(servers[indexOfServer].server.user_id, servers[indexOfServer].server.password, servers[indexOfServer].server.ip_address, 5432, servers[indexOfServer].server.default_database, servers[indexOfServer].server.config_plus))
                                {
                                    
                                    sqlScript = sqlScript.Replace(":Albaran", String.Format("\'{0}\'", compra.ALBARAN));
                                    sql.advancedSeek(sqlScript);
                                    DataTable dt = sql.fillDataTable();
                                    // validate from CBOS
                                    dt.Dispose();
                                    
                                }
                                break;
                            }
                    }

                    importeVenta += compra.PRECIO_UNITARIO;
                    transact++;
                    // Agregamos la compra a la EDS
                    station.obj_compras.Add(compra);
                }

                station.Precio_Compra = importeVenta / transact;
            }
        }

        private void procesa_genera_salidaCompras()
        {
            string output_file = system[0].purchase_output.Replace("yyyy", BeginDate.Year.ToString()).Replace("MM", EndDate.Month.ToString());
            output_file = output_file.Replace("dd", EndDate.Day.ToString()).Replace("{period}", cls_common_task.getFullMonth(EndDate.Month));            
            string output_purchase_file = "";

            string output_original = output_file;

            purchase_log = string.Format(@"{0}\{1}", Path.GetDirectoryName(Application.ExecutablePath), ini.generate_json_log);
            var logPurchase = new cls_common_task.procesarArchivos(purchase_log);
            DataTable dtPurchase = logPurchase.CrearTable("myPurchaseLog");

            dtPurchase.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Instrucciones JSON de compras");
            dtPurchase.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> EDS por procesar {0} ", obj_stations.Count));

            try
            {

                switch (system[0].purchase_output_file)
                {
                    case OUTPUT_INSERT_EDS:
                    {
                        dtPurchase.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", " Base de datos EDS"));
                        break;
                    }
                    case OUTPUT_SCRIPT_EDS:
                    {
                            
                        dtPurchase.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", " Script para EDS"));

                        StringBuilder script;                          
                        //int count = 0;
                        foreach (var estacion in obj_stations)
                        {
                            output_file = output_original.Replace("{station}", estacion.ESTACION);
                            output_purchase_file = string.Format(@"{0}\{1}.sql", system[0].purchase_output_path, output_file);

                            dtPurchase.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Destino: <b>{0}</b> ", output_purchase_file));

                            //if (count == 0) {
                            script = new StringBuilder();
                            script.AppendLine("DELETE FROM ppv.tpcfdi WHERE cfdi_fecha >= '" + BeginDate + "' AND cfdi_fecha <= '" + EndDate + "' AND cfdi_tipo = 'E';");

                            StringBuilder str = new StringBuilder();

                            foreach (var compra in estacion.obj_compras)
                            {
                                str.Append("/* " + estacion.ESTACION + " */");
                                str.Append("/*  generado desde GasStationTools */");
                                str.Append("/*  by: José Luján, DOTECH */");

                                str.Append("INSERT INTO ppv.tpcfdi (cfdi_uuid,cfdi_tipo,cfdi_fecha,cfdi_hora,fecha_oper,litros,num_factu,nnif,cfdi_nombre,cv_permisop,codigo_tpv,numero_recep," +
                                    "linea_oper, precio_compra,cfdi_producto,cfdi_total,cfdi_tipo_sat,reserva2,precio_unitario,precio_venta_iva) SELECT ");
                                str.Append("'" + compra.UUID + "'"); str.Append(",");//cfdi_uuid
                                str.Append("'E'"); str.Append(",");//cfdi_tipo
                                str.Append(string.Format("Convert.ToDateTime('{0}'),", compra.FECHA_TIMBRADO.ToShortDateString()));//cfdi_fecha
                                str.Append(string.Format("Convert.ToDateTime('{0}'),", compra.FECHA_TIMBRADO.ToShortTimeString())); //cfdi_hora
                                str.Append(string.Format("Convert.ToDateTime('{0}'),", compra.FECHA.ToString("yyyyMMdd"))); //fecha_oper
                                str.Append(string.Format("{0},", compra.VOLUMEN_FACTURADO));//litros
                                str.Append(string.Format("'{0}',", compra.ALBARAN)); //num_factu
                                str.Append(string.IsNullOrEmpty(compra.NUM_PROVEEDOR.rfc) ? throw new Exception(string.Format("'RFC Vacio para Albaran: {0}'",compra.ALBARAN)) : string.Format("RFC: {0}", compra.NUM_PROVEEDOR.rfc));  //nnif
                                str.Append(string.IsNullOrEmpty(compra.NUM_PROVEEDOR.nombre) ? "NULL" : "'" + compra.NUM_PROVEEDOR.nombre + "',");//nombre
                                str.Append(string.IsNullOrEmpty(compra.NUM_PROVEEDOR.permiso1) ? throw new Exception("Permiso Vacio para Albaran" + compra.ALBARAN) : "'" + compra.NUM_PROVEEDOR.permiso1 + "'"); str.Append(",");//cv_permisop
                                str.Append("'001'"); str.Append(",");//codigo_tpv
                                str.Append(string.IsNullOrEmpty(compra.ID_DESCARGA) ? "NULL" : compra.ID_DESCARGA); str.Append(","); //numero_recep
                                str.Append(string.IsNullOrEmpty(compra.LINEA_OPER) ? "NULL" : compra.LINEA_OPER); str.Append(",");  //linea_oper
                                str.Append(estacion.Precio_Compra); str.Append(",");//precio_compra
                                str.Append(string.IsNullOrEmpty(compra.CODIGO_PRODUCTO) ? "NULL" : "'" + compra.CODIGO_PRODUCTO + "'"); str.Append(",");//cfdi_producto
                                str.Append(compra.TOTAL); str.Append(","); //cfdi_total
                                str.Append("'INGRESO'"); str.Append(",");//cfdi_tipo_sat
                                str.Append(string.IsNullOrEmpty(compra.PRODUCTO) ? "NULL" : "'" + compra.PRODUCTO + "'"); str.Append(",");//reserva2
                                str.Append(compra.PRECIO_UNITARIO); str.Append(",");  //precio_unitario
                                str.Append(compra.PRECIO_UNITARIO);  //precio_venta_iva
                                str.Append(" where not exists (SELECT 1 FROM ppv.tpcfdi WHERE ");
                                str.Append("cfdi_uuid = " + "'" + compra.UUID + "'"); //cfdi_uuid
                                str.Append(" AND ");
                                str.Append("cfdi_tipo =  'E'");
                                str.Append(" AND ");
                                str.Append("num_factu =  " + (string.IsNullOrEmpty(compra.ALBARAN) ? "''" : "'" + compra.ALBARAN + "'"));
                                str.Append(" AND ");
                                str.Append("precio_compra = " + estacion.Precio_Compra);
                                str.Append(" AND ");
                                str.Append("cfdi_producto = " + (string.IsNullOrEmpty(compra.CODIGO_PRODUCTO) ? "'0'" : "'" + compra.CODIGO_PRODUCTO + "'"));
                                str.Append(");");

                            }

                            script.AppendLine(str.ToString());
                            //script.AppendLine(
                            //    string.Format("SELECT COUNT(*) AS \"Result\",inet_server_addr() AS \"IP Servidor\",(SELECT nombre_esta FROM estagas.estaser) as estacion,(SELECT num_concesion FROM estagas.estaser) as id_estacion,max(_ts) fecha_ultima_migracion FROM ppv.tpcfdi WHERE cfdi_tipo = 'E' AND cfdi_fecha>=CONVERT(DATETIME,'{0}',103) AND cfdi_fecha<=CONVERT(DATETIME,'{0}',103)';",
                            //    BeginDate.ToString(), EndDate.ToString()));

                            //if (File.Exists(output_purchase_file))
                            //{
                            //    File.Delete(output_purchase_file);
                            //}
                            FileStream fs = File.Create(@output_purchase_file);
                            byte[] content = new UTF8Encoding(true).GetBytes(script.ToString().Replace("‘", " ").Replace("•", " ").Replace("—", " ").Replace("�", " "));
                            fs.Write(content, 0, content.Length);
                            fs.Close();
                        }

                        break;
                    }
                }
            }

            catch (Exception ex)
            {
                dtPurchase.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Error {0} ", ex.Message));
                notify_log_process(dtPurchase, CRASH_JOB_PURCHASE);
            }
            finally
            {

                dtPurchase.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", "Finaliza proceso JSON de compras"));
                dtPurchase.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", ""));

                logPurchase.asignarDataTable(dtPurchase);
                logPurchase.archivosProcesados();

                if (system[0].all_activity_log)
                {
                    notify_log_process(dtPurchase, "Fin de instrucciones JSON de compras", "", "");
                }
            }
        }
    }
}


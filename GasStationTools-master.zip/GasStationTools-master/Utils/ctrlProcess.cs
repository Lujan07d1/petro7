﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GasStationTools.Utils

{
    public partial class ctrlProcess : DevExpress.XtraEditors.XtraUserControl
    {
        private bool changeValues = false;
        private DataTable log;

        [
            Category("Process"),
            Description("Validar que se realizaron cambios en el proceso/tarea seleccionada")
        ]       
        public bool changeProcess
        {
            get
            {
                return changeValues;
            }
            set
            {
                changeValues = value;             
            }
        }

        public DataTable getsetLog
        {
            get { return log; }
            set { log = CrearTable("logs") ; }
        }

        public DataTable CrearTable(string nombreTabla)
        {
            //
            // Here we create a DataTable with TWO columns.
            //
            log = new DataTable();
            log.TableName = nombreTabla;
            log.Columns.Add("Date", typeof(DateTime));
            log.Columns.Add("Message", typeof(string));

            return log;
        }

        public ctrlProcess()
        {
            InitializeComponent();            
        }

        private void ctrlProcess_Load(object sender, EventArgs e)
        {
            folderBrowserDialog1.Description = "Seleccione el directorio donde reside el archivo a procesar.";
            folderBrowserDialog1.ShowNewFolderButton = false;
            folderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer;
            tglSource_Toggled(null, null);
        }

        private void tglSource_Toggled(object sender, EventArgs e)
        {
            if (tglSource.IsOn)
            {
                pnlStationBDD.Enabled = true;
                pnlStationFile.Enabled = false;
                lueServer.Focus();
            }
            else
            {
                pnlStationBDD.Enabled = false;
                pnlStationFile.Enabled = true;
                txtPath.Focus();
            }
        }

        private void btnPath_Click(object sender, EventArgs e)
        {
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                txtPath.Text = folderBrowserDialog1.SelectedPath;
                lblPath.Visible = false;
                bntSaveProcess.Enabled = true;
            }
            else
            {
                lblPath.Visible = true;
                bntSaveProcess.Enabled = false;
            }
        }

        private void lueServer_EditValueChanged(object sender, EventArgs e)
        {
            bntSaveProcess.Enabled = true;
        }

        private void txtQuery_EditValueChanged(object sender, EventArgs e)
        {
            bntSaveProcess.Enabled = true;
        }

        private void bntSaveProcess_Click(object sender, EventArgs e)
        {
            bool validExpression = true;
            
            if (txtQuery.Text.ToUpper().Contains("DELETE")) validExpression = false;
            if (txtQuery.Text.ToUpper().Contains("UPDATE")) validExpression = false;
            if (txtQuery.Text.ToUpper().Contains("TRUNCATE")) validExpression = false;
            if (txtQuery.Text.ToUpper().Contains("CREATE")) validExpression = false;
            if (txtQuery.Text.ToUpper().Contains("DROP")) validExpression = false;
            if (txtQuery.Text.ToUpper().Contains("ALTER")) validExpression = false;

            if (txtQuery.Text.ToUpper().Contains(".SQL") || txtQuery.Text.ToUpper().Contains(".TXT"))
            {
                var myFile = Path.GetDirectoryName(Application.ExecutablePath);
                var path = String.Format(@"{0}\Scripts\{1}", myFile, txtQuery.Text);
                if (File.Exists(path))
                {
                    MemoryStream inMemoryCopy = new MemoryStream();
                    using (FileStream fs = File.OpenRead(path))
                    {
                        fs.CopyTo(inMemoryCopy);
                    }

                    using (TextReader textReader = new StreamReader(inMemoryCopy))
                    {
                        string line;
                        while ((line = textReader.ReadLine()) != null)
                        {
                            if (line.ToUpper().Contains("DELETE")) validExpression = false;
                            if (line.ToUpper().Contains("UPDATE")) validExpression = false;
                            if (line.ToUpper().Contains("TRUNCATE")) validExpression = false;
                            if (line.ToUpper().Contains("CREATE")) validExpression = false;
                            if (line.ToUpper().Contains("DROP")) validExpression = false;
                            if (line.ToUpper().Contains("ALTER")) validExpression = false;

                            if (!validExpression) break;
                        }
                    }
                }
                else validExpression = false;
            }

            if (validExpression == false)
            {
                MessageBox.Show("Se encontraron instrucciones no permitidas", "Advertencia");
                log.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Intento de inyección de código SQL O formato de archivo no permitido [{0}] ", txtQuery.Text.Trim()));
                log.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", ""));

                txtQuery.SelectAll();
                return;
            }
            else changeValues = true;
        }

        private void btnChar_Click(object sender, EventArgs e)
        {
            txtColumns.Text += "|";           
            txtColumns.Focus();
        }

        private void pnlBody_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

﻿
namespace GasStationTools.Utils
{
    partial class ctrlProcess
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ctrlProcess));
            this.pnlBody = new DevExpress.XtraEditors.PanelControl();
            this.tglSource = new DevExpress.XtraEditors.ToggleSwitch();
            this.pnlStationFile = new DevExpress.XtraEditors.PanelControl();
            this.lblPath = new DevExpress.XtraEditors.LabelControl();
            this.txtExtension = new DevExpress.XtraEditors.TextEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.txtPrefix = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.btnPath = new DevExpress.XtraEditors.SimpleButton();
            this.txtPath = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.pnlStationBDD = new DevExpress.XtraEditors.PanelControl();
            this.txtQuery = new DevExpress.XtraEditors.MemoEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.lueServer = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.btnChar = new DevExpress.XtraEditors.SimpleButton();
            this.bntSaveProcess = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtColumns = new DevExpress.XtraEditors.MemoEdit();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.pnlBody)).BeginInit();
            this.pnlBody.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tglSource.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlStationFile)).BeginInit();
            this.pnlStationFile.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtExtension.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrefix.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPath.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlStationBDD)).BeginInit();
            this.pnlStationBDD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuery.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueServer.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtColumns.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBody
            // 
            this.pnlBody.Controls.Add(this.txtColumns);
            this.pnlBody.Controls.Add(this.pnlStationFile);
            this.pnlBody.Controls.Add(this.labelControl1);
            this.pnlBody.Controls.Add(this.tglSource);
            this.pnlBody.Controls.Add(this.btnChar);
            this.pnlBody.Controls.Add(this.pnlStationBDD);
            this.pnlBody.Controls.Add(this.bntSaveProcess);
            this.pnlBody.Controls.Add(this.labelControl8);
            this.pnlBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBody.Location = new System.Drawing.Point(0, 0);
            this.pnlBody.Name = "pnlBody";
            this.pnlBody.Size = new System.Drawing.Size(952, 590);
            this.pnlBody.TabIndex = 9;
            this.pnlBody.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlBody_Paint);
            // 
            // tglSource
            // 
            this.tglSource.EnterMoveNextControl = true;
            this.tglSource.Location = new System.Drawing.Point(24, 46);
            this.tglSource.Name = "tglSource";
            this.tglSource.Properties.OffText = "Archivo CSV o XLSX";
            this.tglSource.Properties.OnText = "Consulta base datos";
            this.tglSource.Size = new System.Drawing.Size(258, 26);
            this.tglSource.TabIndex = 1;
            this.tglSource.Toggled += new System.EventHandler(this.tglSource_Toggled);
            // 
            // pnlStationFile
            // 
            this.pnlStationFile.Controls.Add(this.lblPath);
            this.pnlStationFile.Controls.Add(this.txtExtension);
            this.pnlStationFile.Controls.Add(this.labelControl7);
            this.pnlStationFile.Controls.Add(this.txtPrefix);
            this.pnlStationFile.Controls.Add(this.labelControl6);
            this.pnlStationFile.Controls.Add(this.btnPath);
            this.pnlStationFile.Controls.Add(this.txtPath);
            this.pnlStationFile.Controls.Add(this.labelControl5);
            this.pnlStationFile.Location = new System.Drawing.Point(23, 92);
            this.pnlStationFile.Name = "pnlStationFile";
            this.pnlStationFile.Size = new System.Drawing.Size(434, 303);
            this.pnlStationFile.TabIndex = 4;
            // 
            // lblPath
            // 
            this.lblPath.Appearance.Font = new System.Drawing.Font("Tahoma", 6.8F);
            this.lblPath.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lblPath.Appearance.Options.UseFont = true;
            this.lblPath.Appearance.Options.UseForeColor = true;
            this.lblPath.Location = new System.Drawing.Point(65, 41);
            this.lblPath.Name = "lblPath";
            this.lblPath.Size = new System.Drawing.Size(146, 13);
            this.lblPath.TabIndex = 23;
            this.lblPath.Text = "* La ruta es un dato requerido";
            // 
            // txtExtension
            // 
            this.txtExtension.Location = new System.Drawing.Point(130, 99);
            this.txtExtension.Name = "txtExtension";
            this.txtExtension.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtExtension.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtExtension.Size = new System.Drawing.Size(60, 22);
            this.txtExtension.TabIndex = 11;
            this.txtExtension.ToolTip = "Extensión o extensiones que podrá tener el archivo origen";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(65, 102);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(59, 16);
            this.labelControl7.TabIndex = 10;
            this.labelControl7.Text = "Extensión:";
            // 
            // txtPrefix
            // 
            this.txtPrefix.Location = new System.Drawing.Point(65, 63);
            this.txtPrefix.Name = "txtPrefix";
            this.txtPrefix.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtPrefix.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtPrefix.Properties.NullValuePrompt = "Nombre del archivo que identifica a las estaciones";
            this.txtPrefix.Size = new System.Drawing.Size(248, 22);
            this.txtPrefix.TabIndex = 9;
            this.txtPrefix.ToolTip = "Nombre completo o palabras clave del nombre del archivo que identificara el proce" +
    "so\r\n\r\nAcepta comodines (*, ?, _)";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(17, 66);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(42, 16);
            this.labelControl6.TabIndex = 8;
            this.labelControl6.Text = "Prefijo:";
            // 
            // btnPath
            // 
            this.btnPath.Location = new System.Drawing.Point(384, 16);
            this.btnPath.Name = "btnPath";
            this.btnPath.Size = new System.Drawing.Size(32, 25);
            this.btnPath.TabIndex = 7;
            this.btnPath.Text = "...";
            this.btnPath.Click += new System.EventHandler(this.btnPath_Click);
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(65, 18);
            this.txtPath.Name = "txtPath";
            this.txtPath.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtPath.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtPath.Properties.NullValuePrompt = "Ruta de trabajo donde se realizará la busqueda de archivos de configuración";
            this.txtPath.Size = new System.Drawing.Size(317, 22);
            this.txtPath.TabIndex = 6;
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(28, 21);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(31, 16);
            this.labelControl5.TabIndex = 5;
            this.labelControl5.Text = "Ruta:";
            // 
            // pnlStationBDD
            // 
            this.pnlStationBDD.Controls.Add(this.txtQuery);
            this.pnlStationBDD.Controls.Add(this.labelControl4);
            this.pnlStationBDD.Controls.Add(this.lueServer);
            this.pnlStationBDD.Controls.Add(this.labelControl3);
            this.pnlStationBDD.Enabled = false;
            this.pnlStationBDD.Location = new System.Drawing.Point(487, 92);
            this.pnlStationBDD.Name = "pnlStationBDD";
            this.pnlStationBDD.Size = new System.Drawing.Size(434, 303);
            this.pnlStationBDD.TabIndex = 3;
            // 
            // txtQuery
            // 
            this.txtQuery.Location = new System.Drawing.Point(17, 59);
            this.txtQuery.Name = "txtQuery";
            this.txtQuery.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtQuery.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtQuery.Size = new System.Drawing.Size(399, 227);
            this.txtQuery.TabIndex = 8;
            this.txtQuery.EditValueChanged += new System.EventHandler(this.txtQuery_EditValueChanged);
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(21, 40);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(67, 16);
            this.labelControl4.TabIndex = 5;
            this.labelControl4.Text = "Instrucción:";
            // 
            // lueServer
            // 
            this.lueServer.Location = new System.Drawing.Point(93, 12);
            this.lueServer.Name = "lueServer";
            this.lueServer.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.lueServer.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.lueServer.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lueServer.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("description", "Server")});
            this.lueServer.Properties.DisplayMember = "description";
            this.lueServer.Properties.ValueMember = "description";
            this.lueServer.Size = new System.Drawing.Size(229, 22);
            this.lueServer.TabIndex = 4;
            this.lueServer.EditValueChanged += new System.EventHandler(this.lueServer_EditValueChanged);
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(21, 15);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(53, 16);
            this.labelControl3.TabIndex = 3;
            this.labelControl3.Text = "Servidor:";
            // 
            // btnChar
            // 
            this.btnChar.Image = ((System.Drawing.Image)(resources.GetObject("btnChar.Image")));
            this.btnChar.Location = new System.Drawing.Point(639, 438);
            this.btnChar.Name = "btnChar";
            this.btnChar.Size = new System.Drawing.Size(36, 37);
            this.btnChar.TabIndex = 24;
            this.btnChar.ToolTip = "Insertar delimitador de columnas ";
            this.btnChar.Click += new System.EventHandler(this.btnChar_Click);
            // 
            // bntSaveProcess
            // 
            this.bntSaveProcess.Enabled = false;
            this.bntSaveProcess.Image = ((System.Drawing.Image)(resources.GetObject("bntSaveProcess.Image")));
            this.bntSaveProcess.Location = new System.Drawing.Point(796, 492);
            this.bntSaveProcess.Name = "bntSaveProcess";
            this.bntSaveProcess.Size = new System.Drawing.Size(142, 74);
            this.bntSaveProcess.TabIndex = 24;
            this.bntSaveProcess.Text = "Grabar cambios";
            this.bntSaveProcess.ToolTip = "Salvar los cambios de la configuración del servidor seleccionado.";
            this.bntSaveProcess.Click += new System.EventHandler(this.bntSaveProcess_Click);
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(27, 447);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(296, 16);
            this.labelControl8.TabIndex = 6;
            this.labelControl8.Text = "Columnas  para validar Entrada (separadas por \"|\")";
            // 
            // txtColumns
            // 
            this.txtColumns.Location = new System.Drawing.Point(24, 469);
            this.txtColumns.Name = "txtColumns";
            this.txtColumns.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtColumns.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtColumns.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtColumns.Size = new System.Drawing.Size(652, 105);
            this.txtColumns.TabIndex = 7;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(27, 24);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(157, 16);
            this.labelControl1.TabIndex = 27;
            this.labelControl1.Text = "Orígen de datos de Entrada";
            // 
            // ctrlProcess
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.Controls.Add(this.pnlBody);
            this.Name = "ctrlProcess";
            this.Size = new System.Drawing.Size(952, 590);
            this.Load += new System.EventHandler(this.ctrlProcess_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pnlBody)).EndInit();
            this.pnlBody.ResumeLayout(false);
            this.pnlBody.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tglSource.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlStationFile)).EndInit();
            this.pnlStationFile.ResumeLayout(false);
            this.pnlStationFile.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtExtension.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrefix.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPath.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pnlStationBDD)).EndInit();
            this.pnlStationBDD.ResumeLayout(false);
            this.pnlStationBDD.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtQuery.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueServer.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtColumns.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl pnlBody;
        private DevExpress.XtraEditors.SimpleButton bntSaveProcess;
        private DevExpress.XtraEditors.PanelControl pnlStationFile;
        private DevExpress.XtraEditors.LabelControl lblPath;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.PanelControl pnlStationBDD;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        public DevExpress.XtraEditors.SimpleButton btnChar;
        public DevExpress.XtraEditors.TextEdit txtExtension;
        public DevExpress.XtraEditors.TextEdit txtPrefix;
        public DevExpress.XtraEditors.SimpleButton btnPath;
        public DevExpress.XtraEditors.TextEdit txtPath;
        public DevExpress.XtraEditors.MemoEdit txtColumns;
        public DevExpress.XtraEditors.MemoEdit txtQuery;
        public DevExpress.XtraEditors.LookUpEdit lueServer;
        public DevExpress.XtraEditors.ToggleSwitch tglSource;
        private DevExpress.XtraEditors.LabelControl labelControl1;
    }
}

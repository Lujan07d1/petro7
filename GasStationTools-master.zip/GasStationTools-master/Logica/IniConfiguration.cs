﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.IO;
using GasStationTools.Logica;

namespace GasStationTools.Logica
{
    public class IniConfiguration
    {
        private string exe_path { get; set; }
        public string generate_json_readme { get; set; }
        public string generate_json_log { get; set; }
        public string generate_json_exe { get; set; }
        public string generate_json_exe_path { get; set; }
        
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section,
            string key, string val, string filePath);
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section,
                 string key, string def, StringBuilder retVal,
            int size, string filePath);

        /// <summary>
        /// INIFile Constructor.
        /// </summary>
        /// <PARAM name="INIPath"></PARAM>
        public IniConfiguration(string INIPath, string howSys = "GasStationTools")
        {
            exe_path = INIPath;
            if (!File.Exists(exe_path))
            {
                switch (howSys)
                {
                    case "GasStationTools":
                        {
                            IniWriteValue("config_json_data_sys", "readme_file", @"json_data_readme.txt");
                            IniWriteValue("config_json_data_sys", "log_file", @"automation_json_log.txt");
                            IniWriteValue("config_json_data_sys", "executable", "GasStationTools.exe");
                            IniWriteValue("config_json_data_sys", "json_path", @"c:\work\P7_AUTOMATIZACION_JSON\");
                            break;
                        }                   
                }
            }


            leerConfiguracion();
        }

        /// <summary>
        /// INIFile Constructor.
        /// </summary>
        /// <PARAM name="INIPath"></PARAM>
        public IniConfiguration(string INIPath)
        {
            exe_path = INIPath;
            if (!File.Exists(exe_path))
            {
                IniWriteValue("config_json_data_sys", "readme_file", @"json_data_readme.txt");
                IniWriteValue("config_json_data_sys", "log_file", @"automation_json_log.txt");
                IniWriteValue("config_json_data_sys", "executable", "GasStationTools.exe");
                IniWriteValue("config_json_data_sys", "json_path", @"c:\work\P7_AUTOMATIZACION_JSON\");
            }
            leerConfiguracion();
        }
        /// <summary>
        /// Write Data to the INI File
        /// </summary>
        /// <PARAM name="Section"></PARAM>
        /// Section name
        /// <PARAM name="Key"></PARAM>
        /// Key Name
        /// <PARAM name="Value"></PARAM>
        /// Value Name
        public void IniWriteValue(string Section, string Key, string Value)
        {
            WritePrivateProfileString(Section, Key, Value, this.exe_path);
        }

        /// <summary>
        /// Read Data Value From the Ini File
        /// </summary>
        /// <PARAM name="Section"></PARAM>
        /// <PARAM name="Key"></PARAM>
        /// <PARAM name="Path"></PARAM>
        /// <returns></returns>
        public string IniReadValue(string Section, string Key)
        {
            StringBuilder temp = new StringBuilder(255);
            int i = GetPrivateProfileString(Section, Key, "", temp,
                                            255, this.exe_path);
            return temp.ToString();

        }

        public void leerConfiguracion()
        {
            generate_json_readme = IniReadValue("config_json_data_sys", "readme_file");
            generate_json_log = IniReadValue("config_json_data_sys", "log_file");
            generate_json_exe = IniReadValue("config_json_data_sys", "executable");
            generate_json_exe_path = IniReadValue("config_json_data_sys", "json_path");
         
        }
    }
}





﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace GasStationTools.Logica
{
    public class cls_smtp_config_send_mail
    {
        private SmtpClient client;
        private MailMessage objeto_mail;
        private String username;
        public Boolean AVAILABLE_HOST { get; set; }

        public cls_smtp_config_send_mail()
        {
            AVAILABLE_HOST = false;
        }

        /// <summary>
        /// Configurar cliente de correo electrónico desde que se carga el sistema, por José Luján
        /// Grillo Development 2018
        /// </summary>
        /// <param name="Host"></param>
        /// <param name="Port"></param>
        /// <param name="SSL"></param>
        /// <param name="Timeout"></param>
        /// <param name="Username"></param>
        /// <param name="Password"></param>
        public cls_smtp_config_send_mail(String Host, int Port, Boolean SSL, int Timeout, String Username, String Password)
        {
            client = new SmtpClient();
            client.Port = Port;
            client.Host = Host;
            client.EnableSsl = SSL;
            client.Timeout = Timeout;

            client.DeliveryMethod = SmtpDeliveryMethod.Network;

            client.UseDefaultCredentials = true;
            client.Credentials = new System.Net.NetworkCredential(Username, Password);

            username = Username;
        }


        /// <summary>
        /// Correo listo para enviarse
        /// </summary>        
        /// <param name="email_address_to"></param>
        /// <param name="subject"></param>
        /// <param name="Body"></param>        
        public void send_mail(String email_address_to, String subject, String Body, String title)
        {
            objeto_mail = new MailMessage();
            objeto_mail.From = new MailAddress(username, title);

            objeto_mail.BodyEncoding = System.Text.Encoding.GetEncoding("utf-8"); // System.Text.Encoding.GetEncoding("iso-8859-1");
            objeto_mail.SubjectEncoding = System.Text.Encoding.Default;
            objeto_mail.IsBodyHtml = true;
            //objeto_mail.From.DisplayName = "";
            //objeto_mail.From.User = username;
            //objeto_mail.From.Host = "mail.grillodev.com";
            //ppgrillo07d1@gmail.com; jlujan@grillodev.com

            //Revisar
            var send_to_zero = email_address_to.Split(';');
     
            // Traer direcciones a notificar
            for (int i = 0; i < send_to_zero.Length; i++)
            {
                if (send_to_zero[i] != null) objeto_mail.To.Add(new MailAddress(send_to_zero[i]));
            }

            // Body += "<br/><br/>Enjoy all The Productivity of Your Bussiness<br/> <a href=\"http://www.grillodev.com\"><img src=\"http://www.grillodev.com/logotipo.png\" alt=\"Grillo Development\" height=\"25\" width=\"92\"></a> ";

            objeto_mail.Subject = subject;
            objeto_mail.Body = Body; //mensaje(String Body, _origen, _usuario, _cadena);
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
                { return true; };

                client.Send(objeto_mail);                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }
    }
}

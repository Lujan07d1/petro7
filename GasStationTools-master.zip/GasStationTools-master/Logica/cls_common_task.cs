﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GasStationTools.Logica
{
    public static class cls_common_task
    {
        public class procesarArchivos
        {
            private DataTable table;
            private string logFile;

            public procesarArchivos(string _logFile) { logFile = _logFile; }

            public DataTable CrearTable(string nombreTabla)
            {
                //
                // Here we create a DataTable with TWO columns.
                //
                table = new DataTable();
                table.TableName = nombreTabla;
                table.Columns.Add("Date", typeof(DateTime));                
                table.Columns.Add("Message", typeof(string));
                
                return table;
            }

            public void asignarDataTable(DataTable tablaconDatos)
            {
                table = tablaconDatos;
            }


            public void archivosProcesados()
            {
                var miLogFile = ""; 
                // Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                miLogFile = logFile;

                using (StreamWriter w = File.AppendText(miLogFile))
                // Create a file to write to. 
                {
                    foreach (DataRow row in table.Rows)
                    {                       
                        w.WriteLine(string.Format("{0}|{1}", row["Date"], row["Message"]));                        
                    }
                }
            }           
        }

        public static string getFullMonth(int iMonth)
        {
            string month = "";
            switch (iMonth)
            {
                case 1: { month = "Enero"; break; }
                case 2: { month = "Febrero"; break; }
                case 3: { month = "Marzo"; break; }
                case 4: { month = "Abril"; break; }
                case 5: { month = "Mayo"; break; }
                case 6: { month = "Junio"; break; }
                case 7: { month = "Julio"; break; }
                case 8: { month = "Agosto"; break; }
                case 9: { month = "Septiembre"; break; }
                case 10: { month = "Octubre"; break; }
                case 11: { month = "Noviembre"; break; }
                case 12: { month = "Diciembre"; break; }
            }

            return month;
        }

        public static void SetPropertyValue(this object obj, string propName, object value)
        {
            obj.GetType().GetProperty(propName).SetValue(obj, value, null);
        }

    }
}

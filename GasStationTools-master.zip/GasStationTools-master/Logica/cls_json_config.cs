﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GasStationTools.Logica;
using System.IO;
using Newtonsoft;
using Newtonsoft.Json;
using System.Reflection;

namespace GasStationTools.Logica
{
    public class cls_json_config
    {
        const int SERVER = 1;
        const int PROCESS = 2;
        const int SUPPLIER = 3;
        const int CONFIG = 4;
        const int NOTIFICATION = 5;

        //private StringCipher stringCipher;
      
        public Root_Process myConfigurationClass { get; set; }
        public Root_Supplier mySupplierClass { get; set; }

        // Root_Server myDeserializedClass     
        // Root_Process myDeserializedClass = JsonConvert.DeserializeObject<List<Root_Process>>(myJsonResponse);
        // Root_Supplier myDeserializedClass = JsonConvert.DeserializeObject<List<Root_Supplier>>(myJsonResponse);

        public void CreateJsonConfig(string fileName, int step)
        {           
            char space = (char)32;
            if (!Directory.Exists(Path.GetDirectoryName(fileName)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(fileName));
            }
            using (StreamWriter sw = File.CreateText(fileName))
            {
                switch (step)
                {
                    case SERVER:
                        {
                            sw.WriteLine("[");
                            sw.WriteLine("{");
                            sw.WriteLine("\"description\":{0}\"{1}\",", space, StringCipher.Encrypt("CBOS", true));
                            sw.WriteLine("\"server\": {");
                            sw.WriteLine("\"ip_address\":{0}\"{1}\",", space, StringCipher.Encrypt("10.0.7.89", true));
                            sw.WriteLine("\"default_database\":{0}\"{1}\",", space, StringCipher.Encrypt("arcadia_cbos", true));
                            sw.WriteLine("\"user_id\":{0}\"{1}\",", space, StringCipher.Encrypt("Arcadia_DBPROD", true));
                            sw.WriteLine("\"password\":{0}\"{1}\",", space, StringCipher.Encrypt("Arcadia.P7", true));
                            sw.WriteLine("\"config_plus\":{0}\"{1}\",", space, StringCipher.Encrypt("MultipleActiveResultSets=True", true));
                            sw.WriteLine("},");
                            sw.WriteLine("\"platform\":{0}\"{1}\"", space, StringCipher.Encrypt("SQL", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"description\":{0}\"{1}\",", space, StringCipher.Encrypt("KONESH", true));
                            sw.WriteLine("\"server\": {");
                            sw.WriteLine("\"ip_address\":{0}\"{1}\",", space, StringCipher.Encrypt("10.0.7.89", true));
                            sw.WriteLine("\"default_database\":{0}\"{1}\",", space, StringCipher.Encrypt("CFDIP7", true));
                            sw.WriteLine("\"user_id\":{0}\"{1}\",", space, StringCipher.Encrypt("USR_KONESHPRD", true));
                            sw.WriteLine("\"password\":{0}\"{1}\",", space, StringCipher.Encrypt("K0neshPRD6", true));
                            sw.WriteLine("\"config_plus\":{0}\"{1}\",", space, StringCipher.Encrypt("MultipleActiveResultSets=True", true));
                            sw.WriteLine("},");
                            sw.WriteLine("\"platform\":{0}\"{1}\"", space, StringCipher.Encrypt("ORACLE", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"description\":{0}\"{1}\",", space, StringCipher.Encrypt("G5IX", true));
                            sw.WriteLine("\"server\": {");
                            sw.WriteLine("\"ip_address\":{0}\"{1}\",", space, StringCipher.Encrypt("10.160.102.21", true));
                            sw.WriteLine("\"default_database\":{0}\"{1}\",", space, StringCipher.Encrypt("g5ix", true));
                            sw.WriteLine("\"user_id\":{0}\"{1}\",", space, StringCipher.Encrypt("postavalon", true));
                            sw.WriteLine("\"password\":{0}\"{1}\",", space, StringCipher.Encrypt("postavalon", true));
                            sw.WriteLine("\"config_plus\":{0}\"{1}\",", space, StringCipher.Encrypt("", true));
                            sw.WriteLine("},");
                            sw.WriteLine("\"platform\":{0}\"{1}\"", space, StringCipher.Encrypt("POSTGRESQL", true));

                            sw.WriteLine("}");
                            sw.WriteLine("]");

                            break;
                        }
                    case PROCESS:
                        {
                            sw.WriteLine("[");
                            sw.WriteLine("{");
                            sw.WriteLine("\"source\":{0}\"{1}\",", space, StringCipher.Encrypt("ESTACIONES", true));
                            sw.WriteLine("\"configuration\": {");
                            sw.WriteLine("\"server_in\":{0}\"{1}\",", space, StringCipher.Encrypt("", true));
                            sw.WriteLine("\"query_in\":{0}\"{1}\",", space, StringCipher.Encrypt("null", true));
                            sw.WriteLine("\"datasource\":{0}\"{1}\",", space, StringCipher.Encrypt("file", true));
                            sw.WriteLine("\"path\":{0}\"{1}\",", space, StringCipher.Encrypt("c:\\tmp", true));
                            sw.WriteLine("\"prefix\":{0}\"{1}\",", space, StringCipher.Encrypt("estaciones_", true));
                            sw.WriteLine("\"extension\":{0}\"{1}\",", space, StringCipher.Encrypt("csv", true));
                            sw.WriteLine("\"columns\":{0}\"{1}\",", space, StringCipher.Encrypt("ESTACION|IP", true));
                            sw.WriteLine("\"server_out\":{0}\"{1}\",", space, StringCipher.Encrypt("", true));
                            sw.WriteLine("\"query_out\":{0}\"{1}\"", space, StringCipher.Encrypt("null", true));
                            sw.WriteLine("}");
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"source\":{0}\"{1}\",", space, StringCipher.Encrypt("PROVEEDORES", true));
                            sw.WriteLine("\"configuration\": {");
                            sw.WriteLine("\"server_in\":{0}\"{1}\",", space, StringCipher.Encrypt("", true));
                            sw.WriteLine("\"query_in\":{0}\"{1}\",", space, StringCipher.Encrypt("null", true));
                            sw.WriteLine("\"datasource\":{0}\"{1}\",", space, StringCipher.Encrypt("file", true));
                            sw.WriteLine("\"path\":{0}\"{1}\",", space, StringCipher.Encrypt("c:\\tmp", true));
                            sw.WriteLine("\"prefix\":{0}\"{1}\",", space, StringCipher.Encrypt("config.supplier", true));
                            sw.WriteLine("\"extension\":{0}\"{1}\",", space, StringCipher.Encrypt("json", true));
                            sw.WriteLine("\"columns\":{0}\"{1}\",", space, StringCipher.Encrypt("ID|NOMBRE|RFC|PERMISO1|PERMISO2", true));
                            sw.WriteLine("\"server_out\":{0}\"{1}\",", space, StringCipher.Encrypt("", true));
                            sw.WriteLine("\"query_out\":{0}\"{1}\"", space, StringCipher.Encrypt("null", true));
                            sw.WriteLine("}");
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"source\":{0}\"{1}\",", space, StringCipher.Encrypt("COMPRAS", true));
                            sw.WriteLine("\"configuration\": {");
                            sw.WriteLine("\"server_in\":{0}\"{1}\",", space, StringCipher.Encrypt("", true));
                            sw.WriteLine("\"query_in\":{0}\"{1}\",", space, StringCipher.Encrypt("", true));
                            sw.WriteLine("\"datasource\":{0}\"{1}\",", space, StringCipher.Encrypt("query", true));
                            sw.WriteLine("\"path\":{0}\"{1}\",", space, StringCipher.Encrypt("c:\\tmp", true));
                            sw.WriteLine("\"prefix\":{0}\"{1}\",", space, StringCipher.Encrypt("compras_", true));
                            sw.WriteLine("\"extension\":{0}\"{1}\",", space, StringCipher.Encrypt("csv", true));
                            sw.WriteLine("\"columns\":{0}\"{1}\",", space, StringCipher.Encrypt("UUID|TIPO|FECHAYHORATRANSACCION|FECHA|NUMESTACION|RFC|NOMBRECLIENTE|NUMERODEREMISION|PRODUCTO|VOLUMENFACTURADO|TOTALFACTURA|PERMISO|DESCARGA|LINEAOPER|CODPROD|FECHAOPER|PRECIOCOMPRA", true));
                            sw.WriteLine("\"server_out\":{0}\"{1}\",", space, StringCipher.Encrypt("CBOS", true));
                            sw.WriteLine("\"query_out\":{0}\"{1}\"", space, StringCipher.Encrypt("select Uuid,Tipo,FechaHoraTransaccion,Fecha,NumEstacion,RFC,NombreProveedor,NumeroRemision,Producto,VolumenFacturado,TotalFactura,Permiso,CodigoProducto,IdDescarga,LineaOper,PrecioCompra,PrecioVentaIva,PrecioUnitario,ROW_NUMBER ( ) OVER (PARTITION BY UUID ORDER BY Fecha) LINEAOPER from compras where FECHAHORATRANSACCION>=:BeginDate AND FECHAHORATRANSACCION<=:EndDate and NumeroRemision=:Albaran ORDER BY NUMESTACION,FECHAHORATRANSACCION DESC,NUMEROREMISION", true));
                            sw.WriteLine("}");
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"source\":{0}\"{1}\",", space, StringCipher.Encrypt("VENTAS", true));
                            sw.WriteLine("\"configuration\": {");
                            sw.WriteLine("\"server_in\":{0}\"{1}\",", space, StringCipher.Encrypt("KONESH", true));
                            sw.WriteLine("\"query_in\":{0}\"{1}\",", space, StringCipher.Encrypt("EXTRAER_VENTAS_ESTACIONES.SQL", true));
                            sw.WriteLine("\"datasource\":{0}\"{1}\",", space, StringCipher.Encrypt("query", true));
                            sw.WriteLine("\"path\":{0}\"{1}\",", space, StringCipher.Encrypt("c:\\tmp", true));
                            sw.WriteLine("\"prefix\":{0}\"{1}\",", space, StringCipher.Encrypt("ventas_", true));
                            sw.WriteLine("\"extension\":{0}\"{1}\",", space, StringCipher.Encrypt("csv", true));
                            sw.WriteLine("\"columns\":{0}\"{1}\",", space, StringCipher.Encrypt("ESTACION|UUID|TIPO|NOMBRECLIENTE|RFCCLIENTE|PRODUCTO|VOLUMEN|PRECIOVENTA|TOTALFACTURA|FECHAHORATRANSACCION|FECHAVENTA|RESERVA2", true));
                            sw.WriteLine("\"server_out\":{0}\"{1}\",", space, StringCipher.Encrypt("KONESH", true));
                            sw.WriteLine("\"query_out\":{0}\"{1}\"", space, StringCipher.Encrypt("", true));
                            sw.WriteLine("}");
                            sw.WriteLine("}");

                            sw.WriteLine("]");
                            break;
                        }
                    case SUPPLIER:
                        {
                            sw.WriteLine("[");
                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 15322);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("PEMEX TRANSFORMACIÓN INDUSTRIAL", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("PTI151101TE5", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("PL/10537/TRA/OM/2015", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("H/9857/COM/2015", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 19043);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("DISTRIBUIDORA DAGAL S. A. DE C. V.", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("DDA940608NX1", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("H/22036/COM/2018", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 18362);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("VALORES ABC S.A. DE C.V.", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("VAB9403181Y5", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("H/19724/COM/2016", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 17484);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("VITOL MARKETING MEXICO S. DE R.L. DE C.V", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("VMM1608034M7", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("PL/21924/TRA/OM/2018", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("H/20392/COM/2017", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 17898);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("NOVUM MEXICO TRADING S DE RL DE CV", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("NMT160307MZ0", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("PL/11175/TRA/OM/2015", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("H/19477/COM/2016", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 19450);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("ABASTECEDORA DE COMBUSTIBLES DEL PACÍFICO, S. A. DE C. V.", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("ACP000726NG7", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("N/A", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("H/11771/COM/2015", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 3508);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("TRANSPORTES ESPECIALIZADOS SAN ROBERTO", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("TSE000322P5A", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("PL/18969/TRA/OM/2016", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("N/A", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 15992);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("TRAREYSA, S.A. DE C.V.", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("TRA021112CD0", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("PL/13704/TRA/OM/2016", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("N/A", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 19192);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("COMERCIALIZADORA Y DISTRIBUIDORA MARTINEZ Y MARTINEZ S.A. DE C.V.", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("CDM9801154V3", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("PL/13211/TRA/OM/2016", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("H/19952/COM/2017", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 19685);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("ExxonMobil Mexico S.A. de C.V.", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("EME970101A45", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("N/A", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("H/20319/COM/2017", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 19638);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("Transportación Carretera S.A. de C.V.", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("TCA980629FC6", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("PL/18811/TRA/OM/2016", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("N/A", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 19672);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("TRANSPORTES CEPSA SA DE CV", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("TCE900917RU3", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("PL/10480/TRA/OM/2015", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("N/A", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 20054);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("GRUPO GAZPRO, S.A. DE C.V.", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("GGA1506117K7", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("N/A", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("H/21414/COM/2018", true));
                            sw.WriteLine("},");

                            sw.WriteLine("{");
                            sw.WriteLine("\"id\":{0}{1},", space, 21055);
                            sw.WriteLine("\"nombre\":{0}\"{1}\",", space, StringCipher.Encrypt("MGC MEXICO S.A. DE C.V.", true));
                            sw.WriteLine("\"rfc\":{0}\"{1}\",", space, StringCipher.Encrypt("MME141110IJ9", true));
                            sw.WriteLine("\"permiso1\":{0}\"{1}\",", space, StringCipher.Encrypt("N/A", true));
                            sw.WriteLine("\"permiso2\":{0}\"{1}\",", space, StringCipher.Encrypt("H/10376/COM/2015", true));
                            sw.WriteLine("},");

                            sw.WriteLine("]");
                            break;
                        }
                    case CONFIG:
                        {
                            sw.WriteLine("[");
                            sw.WriteLine("{");
                            sw.WriteLine("\"server\":{0}\"{1}\",", space, StringCipher.Encrypt("mail.simsoluciones.com", true));
                            sw.WriteLine("\"port\":{0}\"{1}\",", space, StringCipher.Encrypt("587", true));
                            sw.WriteLine("\"username\":{0}\"{1}\",", space, StringCipher.Encrypt("jlujan@simsoluciones.com", true));
                            sw.WriteLine("\"password\":{0}\"{1}\",", space, StringCipher.Encrypt("jlujan1357", true));
                            sw.WriteLine("\"timeout\":{0}\"{1}\",", space, StringCipher.Encrypt("50000", true));
                            sw.WriteLine("\"ssl\":{0}{1},", space, "true");
                            sw.WriteLine("\"notify_to\":{0}\"{1}\",", space, StringCipher.Encrypt("ppgrillo07d1@gmail.com", true));
                            sw.WriteLine("\"change_config_log\":{0}{1},", space, "true");
                            sw.WriteLine("\"all_activity_log\":{0}{1},", space, "true");
                            sw.WriteLine("\"software_crash_log\":{0}{1},", space, "true");
                            sw.WriteLine("\"only_lastmonth\":{0}{1},", space, "true");
                            sw.WriteLine("\"max_purchase_price\":{0}{1},", space, 22);
                            sw.WriteLine("\"purchase_output_file\":{0}{1},", space, "false");
                            sw.WriteLine("\"sale_output_file\":{0}{1},", space, "false");
                            sw.WriteLine("\"batch_file\":{0}{1},", space, "true");
                            sw.WriteLine("\"purchase_output_path\":{0}\"{1}\",", space, StringCipher.Encrypt("c:\\tmp", true));
                            sw.WriteLine("\"sale_output_path\":{0}\"{1}\",", space, StringCipher.Encrypt("c:\\tmp", true));
                            sw.WriteLine("\"purchase_output\":{0}\"{1}\",", space, StringCipher.Encrypt("{station}_yyyyMMdd_{period}_compras", true));
                            sw.WriteLine("\"sale_output\":{0}\"{1}\",", space, StringCipher.Encrypt("{station}_yyyyMMdd_{period}_ventas", true));

                            sw.WriteLine("}");
                            sw.WriteLine("]");
                            break;
                        }


                    case NOTIFICATION:
                        {

                            break;
                        }

                };
            }
        }
     

        public List<Root_Server> DeserializeServer(string fileName)
        {
            List<Root_Server> root_Servers = new List<Root_Server>();
            //JsonTextReader reader;

            using (StreamReader r = new StreamReader(fileName))
            {
                string json = r.ReadToEnd();             
                root_Servers = JsonConvert.DeserializeObject<List<Root_Server>>(json);
            };

            root_Servers.ForEach(c => c.description = StringCipher.Decrypt(c.description, true));
            root_Servers.ForEach(c => c.platform = StringCipher.Decrypt(c.platform, true));
            root_Servers.ForEach(c => c.server.ip_address = StringCipher.Decrypt(c.server.ip_address, true));
            root_Servers.ForEach(c => c.server.default_database = StringCipher.Decrypt(c.server.default_database, true));
            root_Servers.ForEach(c => c.server.user_id = StringCipher.Decrypt(c.server.user_id, true));
            root_Servers.ForEach(c => c.server.password = StringCipher.Decrypt(c.server.password, true));
            root_Servers.ForEach(c => c.server.config_plus = StringCipher.Decrypt(c.server.config_plus, true));

            return root_Servers;
        }

        public List<Root_Process> DeserializeProcess(string fileName)
        {
            List<Root_Process> root_Process = new List<Root_Process>();
            //JsonTextReader reader;

            using (StreamReader r = new StreamReader(fileName))
            {
                string json = r.ReadToEnd();
                root_Process = JsonConvert.DeserializeObject<List<Root_Process>>(json);
            };

            root_Process.ForEach(c => c.source = StringCipher.Decrypt(c.source, true));
            root_Process.ForEach(c => c.configuration.server_in = StringCipher.Decrypt(c.configuration.server_in, true));
            root_Process.ForEach(c => c.configuration.query_in = StringCipher.Decrypt(c.configuration.query_in, true));
            root_Process.ForEach(c => c.configuration.datasource = StringCipher.Decrypt(c.configuration.datasource, true));
            root_Process.ForEach(c => c.configuration.path = StringCipher.Decrypt(c.configuration.path, true));
            root_Process.ForEach(c => c.configuration.prefix = StringCipher.Decrypt(c.configuration.prefix, true));
            root_Process.ForEach(c => c.configuration.extension = StringCipher.Decrypt(c.configuration.extension, true));
            root_Process.ForEach(c => c.configuration.columns = StringCipher.Decrypt(c.configuration.columns, true));
            root_Process.ForEach(c => c.configuration.server_out = StringCipher.Decrypt(c.configuration.server_out, true));
            root_Process.ForEach(c => c.configuration.query_out = StringCipher.Decrypt(c.configuration.query_out, true));

            return root_Process;
        }

        public List<Root_Supplier> DeserializeSupplier(string fileName)
        {
            List<Root_Supplier> root_Supplier = new List<Root_Supplier>();
            //JsonTextReader reader;

            using (StreamReader r = new StreamReader(fileName))
            {
                string json = r.ReadToEnd();
                root_Supplier = JsonConvert.DeserializeObject<List<Root_Supplier>>(json);
            };

            root_Supplier.ForEach(c => c.nombre = StringCipher.Decrypt(c.nombre, true));
            root_Supplier.ForEach(c => c.rfc = StringCipher.Decrypt(c.rfc, true));
            root_Supplier.ForEach(c => c.permiso1 = StringCipher.Decrypt(c.permiso1, true));
            root_Supplier.ForEach(c => c.permiso2 = StringCipher.Decrypt(c.permiso2, true));

            return root_Supplier;
        }

        public List<Root_Config> DeserializeConfig(string fileName)
        {
            List<Root_Config> root_Config = new List<Root_Config>();
            //JsonTextReader reader;

            using (StreamReader r = new StreamReader(fileName))
            {
                string json = r.ReadToEnd();
                root_Config = JsonConvert.DeserializeObject<List<Root_Config>>(json);
            };

            root_Config.ForEach(c => c.server = StringCipher.Decrypt(c.server, true));
            root_Config.ForEach(c => c.port = StringCipher.Decrypt(c.port, true));
            root_Config.ForEach(c => c.username = StringCipher.Decrypt(c.username, true));
            root_Config.ForEach(c => c.password = StringCipher.Decrypt(c.password, true));
            root_Config.ForEach(c => c.timeout = StringCipher.Decrypt(c.timeout, true));
            root_Config.ForEach(c => c.notify_to = StringCipher.Decrypt(c.notify_to, true));
            
            root_Config.ForEach(c => c.purchase_output_path = StringCipher.Decrypt(c.purchase_output_path, true));
            root_Config.ForEach(c => c.sale_output_path = StringCipher.Decrypt(c.sale_output_path, true));
            root_Config.ForEach(c => c.purchase_output = StringCipher.Decrypt(c.purchase_output, true));
            root_Config.ForEach(c => c.sale_output = StringCipher.Decrypt(c.sale_output, true));


            return root_Config;
        }
    }


    public class Root_Server
    {
        public string description { get; set; }
        public Server server { get; set; }
        public string platform { get; set; }
    }

    public class Server
    {
        public string ip_address { get; set; }
        public string default_database { get; set; }
        public string user_id { get; set; }
        public string password { get; set; }
        public string config_plus { get; set; }
    }

    public class Root_Process
    {
        public string source { get; set; }
        public Configuration configuration { get; set; }
    }

    public class Configuration
    {
        public string server_in { get; set; }
        public string query_in { get; set; }
        public string datasource { get; set; }
        public string path { get; set; }
        public string prefix { get; set; }
        public string extension { get; set; }
        public string columns { get; set; }
        public string server_out { get; set; }
        public string query_out { get; set; }
    }
    
    public class Root_Supplier
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public string rfc { get; set; }
        public string permiso1 { get; set; }
        public string permiso2 { get; set; }
    }
    
    public class Root_Config
    {
        public string server { get; set; }
        public string port { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string timeout { get; set; }

        public double max_purchase_price { get; set; }
        public string notify_to { get; set; }
        public bool ssl { get; set; }
        public bool change_config_log { get; set; }
        public bool all_activity_log { get; set; }
        public bool software_crash_log { get; set; }
        public bool only_lastmonth { get; set; }
        public bool purchase_output_file { get; set; }
        public bool sale_output_file { get; set; }
        public bool batch_file { get; set; }

        public string purchase_output_path { get; set; }
        public string sale_output_path { get; set; }
        public string purchase_output{ get; set; }
        public string sale_output { get; set; }

    }

}

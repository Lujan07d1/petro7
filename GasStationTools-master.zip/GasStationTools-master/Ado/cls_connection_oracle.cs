﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;

namespace GasStationTools.Ado
{
    public class cls_connection_oracle : IDisposable
    {
        private OracleConnection myConnection { get; set; }
        private OracleTransaction myTransaction { get; set; }
        private OracleCommand myCommand { get; set; }

        private String user { get; set; }
        private String password { get; set; }
        private String database { get; set; }
        private String server { get; set; }
        private UInt16 port { get; set; }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
            {
                myConnection.Close();
                myConnection.Dispose();
            }
        }


    ~cls_connection_oracle()
        {
        Dispose(false);
    }

    /// <summary>
    /// Crear una instancia de Conexión a Base de Datos, el tratamiento que se le dará dependerá a que servidor se conectará, por el momento solo funcionará con MySQL y SQL Server
    /// </summary>
    /// <param name="User_">El Usuario que tiene derechos sobre la base de datos del Sistema </param>
    /// <param name="Password_">La contraseña asignada previamente por el Administrador</param>
    /// <param name="DataSource_">La Base de Datos donde reside el sistema </param>
    /// <param name="Server_">La dirección IP o DNS del Equipo que hace las veces de Servidor</param>
    /// <param name="Port_">Puerto por el cual se realizará la conexión: 1521/1522 para Oracle, 3306-3308 para MySql, 1433 para SQL Server</param>
    /// <param name="Database_">Nombre de la base de datos a la que nos conectaremos</param>
    public cls_connection_oracle(String User_, String Password_, String Server_, UInt16 Port_, String Database_, String _extra)
        {
            user = User_;
            password = Password_;
            port = Port_;
            server = Server_;
            database = Database_;

            myConnection = new OracleConnection { ConnectionString = String.Format(@"data source={0};user id={1};password={2};{3}", server, user, password, _extra) };

            try
            {
                myConnection.Open();
            }
            catch (System.Exception ex)
            {
                throw new Exception("Error Trying connect to Database Server, please review parameters... " + ex.Message + " No." + ex.Source, ex);
            }
        }

        public Boolean initTransaction(String myTrans = "")
        {
            try
            {
                myTransaction = myConnection.BeginTransaction();
                return true;
            }
            catch (System.Exception ex)
            {
                throw new Exception("Error Trying Init Transaction, please review", ex);
            }
        }

        public Boolean commitTransaction()
        {
            try
            {
                myTransaction.Commit();
                return true;
            }
            catch (System.Exception ex)
            {
                try
                {
                    myTransaction.Rollback();
                }
                catch (Exception ex2)
                {
                    // This catch block will handle any errors that may have occurred
                    // on the server that would cause the rollback to fail, such as
                    // a closed connection.
                    throw new Exception(String.Format("Rollback Exception Type: {0} {1}", ex2.GetType(), ex2.Message));
                }
                throw new Exception(String.Format("Fatal Error, Commit Transaction not available, please review: {0} {1}", ex.Message, ex.GetType()));

                // Attempt to roll back the transaction.
            }
        }

        public void rollBackTransaction()
        {
            if (myTransaction.Connection != null) myTransaction.Rollback();
        }

        public void closeConnection()
        {
            if (myConnection == null) return;
            if (myConnection.State == System.Data.ConnectionState.Open)
            {
                myConnection.Close();
            }

        }

        // Métodos para trabajar con la Base de Datos
        #region "Métodos para trabajar con la Base de Datos"

        /// <summary>
        /// Ideal para buscar que el registro exista en la base de Datos... agiliza el proceso de búsqueda y resultados
        /// </summary>
        /// <returns></returns>
        public Int16? executeEscalar()
        {
            var result = Convert.ToInt16(myCommand.ExecuteScalar());
            return result;
        }

        /// <summary>
        /// Ideal para tareas de INSERT, UPDATE, DELETE sobre la Base de Datos.
        /// </summary>        
        public void executeCommand()
        {
            // initTransaction();
            try
            {
                myCommand.ExecuteNonQuery();
            }
            catch (OracleException ex)
            {
                switch (ex.Number)
                {
                    case 0:
                        throw new Exception("---");
                    case 515:
                        throw new Exception("Valores no Permitidos " + ex.Message);
                    default:
                        throw new Exception(String.Format("Error #{0}, generado por {1}", ex.Number, ex.Message));
                }

            }
            catch (System.Exception ex)
            {
                //     rollBackTransaction();
                throw new Exception(String.Format("Error Trying connect to Database Server, please review parameters {1}{1}{0}", ex.Message, Environment.NewLine));
            }
        }

        /// <summary>
        /// Obtiene la información desde la Base de Datos, en un DataTable
        /// </summary>
        /// <returns></returns>
        public DataTable fillDataTable()
        {
            var dtTable = new DataTable();
            using (var adapter = new OracleDataAdapter(myCommand))
            {
                adapter.Fill(dtTable);
            }
            return dtTable;
        }

        /// <summary>
        /// Procedimiento para Agregar los Parametros al comando que ejecutará el Procedimiento de la base de Datos
        /// </summary>
        /// <param name="QueryinBdd"></param>
        /// <param name="_ParametersSP"></param>
        public void defineCommand(String procedimiento, String metodo, SortedDictionary<string, Object> _ParametersSP)
        {
            if (myConnection.State == System.Data.ConnectionState.Open)
            {
                myCommand = new OracleCommand(String.Format("sp{0}", procedimiento), myConnection);
            }
            else
            {
                //Retry to open  moosejaW*1394
                try
                {
                    myConnection.Open();
                }
                catch (System.Exception ex)
                {
                    throw new Exception("Error Trying connect to Database Server, please review parameters, " + ex.Message, ex);
                }
            }

            myCommand.CommandType = System.Data.CommandType.StoredProcedure;
            myCommand.CommandTimeout = 59000;  // 59 segundos
            // Opción que se ejecutará en el Procedimiento Almacenado de la base de Datos
            myCommand.Parameters.Clear();
            myCommand.Parameters.Add(new OracleParameter("@p_option", String.Format("{0}::{1}", procedimiento, metodo)));

            foreach (var kvp in _ParametersSP)
            {
                if (kvp.Key == "@p_docto")
                {
                    myCommand.Parameters.Add(kvp.Key, OracleDbType.LongRaw, 25165824).Value = kvp.Value; // 3MB máximo para documentos
                }
                else if (kvp.Key == "@p_foto")
                {
                    myCommand.Parameters.Add(kvp.Key, OracleDbType.LongRaw).Value = kvp.Value;
                }
                else if (kvp.Key == "@p_last_field")
                {
                    myCommand.Parameters.Add(kvp.Key, OracleDbType.Int32).Direction = ParameterDirection.Output;
                }
                else
                    myCommand.Parameters.Add(new OracleParameter(kvp.Key, (kvp.Value == null) ? DBNull.Value : kvp.Value));
            }
        }


        /// <summary>
        /// Función que devuelte el ID del último registro que se insertó en la base de Datos
        /// </summary>
        /// <returns>Último ID insertado en la base de Datos</returns>
        public Int64 lastInsertID()
        {
            return Convert.ToInt64(myCommand.Parameters["@p_last_field"].Value.ToString());
        }

        /// <summary>
        /// Procedimiento para Las Búsquedas avanzadas del Sistema
        /// </summary>
        /// <param name="cadena">Recibe como parametro la cadena a Buscar para obtener la información de la Vista seleccionada</param>
        /// <param name="_ParametersSP"></param>
        public void advancedSeek(String cadena)
        {
            if (myConnection.State == ConnectionState.Open)
            {
                myCommand = new OracleCommand(cadena, myConnection);
            }
            myCommand.CommandType = CommandType.Text;
        }

        #endregion
    }
}

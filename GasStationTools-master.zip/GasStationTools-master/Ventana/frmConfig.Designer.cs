﻿
namespace GasStationTools.Ventanas
{
    partial class frmConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmConfig));
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.btnTestConection = new DevExpress.XtraEditors.SimpleButton();
            this.lueServer = new DevExpress.XtraEditors.LookUpEdit();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.btnSaveServer = new DevExpress.XtraEditors.SimpleButton();
            this.lblPass = new DevExpress.XtraEditors.LabelControl();
            this.txtConfirmPassword = new DevExpress.XtraEditors.TextEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtConfigPlus = new DevExpress.XtraEditors.TextEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.txtPassword = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.txtUsername = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.txtDatabase = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.txtIP = new DevExpress.XtraEditors.TextEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.luePlataforma = new DevExpress.XtraEditors.LookUpEdit();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage7 = new DevExpress.XtraTab.XtraTabPage();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.xtraTabControl2 = new DevExpress.XtraTab.XtraTabControl();
            this.pageStation = new DevExpress.XtraTab.XtraTabPage();
            this.ctrlProcessStation = new GasStationTools.Utils.ctrlProcess();
            this.pageSupplier = new DevExpress.XtraTab.XtraTabPage();
            this.ctrlProcessSupplier = new GasStationTools.Utils.ctrlProcess();
            this.pagePurchase = new DevExpress.XtraTab.XtraTabPage();
            this.ctrlProcessPurchase = new GasStationTools.Utils.ctrlProcessPurchase();
            this.pageSale = new DevExpress.XtraTab.XtraTabPage();
            this.ctrlProcessSale = new GasStationTools.Utils.ctrlProcessPurchase();
            this.xtraTabPage3 = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.gcSupplier = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.btnSupplier = new DevExpress.XtraEditors.SimpleButton();
            this.xtraTabPage4 = new DevExpress.XtraTab.XtraTabPage();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.btnRefreshLog = new DevExpress.XtraEditors.SimpleButton();
            this.lblModify = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtLog = new DevExpress.XtraEditors.MemoEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabPage5 = new DevExpress.XtraTab.XtraTabPage();
            this.panelControl5 = new DevExpress.XtraEditors.PanelControl();
            this.groupControl4 = new DevExpress.XtraEditors.GroupControl();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.txtFileSaleOUT = new DevExpress.XtraEditors.TextEdit();
            this.txtSalePath = new DevExpress.XtraEditors.TextEdit();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.chkBatch = new DevExpress.XtraEditors.CheckEdit();
            this.txtFilePurchaseOUT = new DevExpress.XtraEditors.TextEdit();
            this.btnPath = new DevExpress.XtraEditors.SimpleButton();
            this.tglCompraConfig = new DevExpress.XtraEditors.ToggleSwitch();
            this.txtPurchasePath = new DevExpress.XtraEditors.TextEdit();
            this.tglVentaConfig = new DevExpress.XtraEditors.ToggleSwitch();
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.chkMesAnterior = new DevExpress.XtraEditors.CheckEdit();
            this.txtPrecioCompra = new DevExpress.XtraEditors.CalcEdit();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.txtNotifyTo = new DevExpress.XtraEditors.MemoEdit();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.chkSSL = new DevExpress.XtraEditors.CheckEdit();
            this.txtPort = new DevExpress.XtraEditors.CalcEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtSMTP = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.txtMailTest = new DevExpress.XtraEditors.TextEdit();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.txtTimeout = new DevExpress.XtraEditors.CalcEdit();
            this.txtSMTPUser = new DevExpress.XtraEditors.TextEdit();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.btnTestSMTP = new DevExpress.XtraEditors.SimpleButton();
            this.txtSMPTPass = new DevExpress.XtraEditors.TextEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.chkCrash = new DevExpress.XtraEditors.CheckEdit();
            this.chkAllLog = new DevExpress.XtraEditors.CheckEdit();
            this.chkConfig = new DevExpress.XtraEditors.CheckEdit();
            this.btnChangeSystem = new DevExpress.XtraEditors.SimpleButton();
            this.xtraTabPage6 = new DevExpress.XtraTab.XtraTabPage();
            this.panelControl4 = new DevExpress.XtraEditors.PanelControl();
            ((System.ComponentModel.ISupportInitialize)(this.lueServer.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtConfirmPassword.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtConfigPlus.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUsername.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDatabase.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIP.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.luePlataforma.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl2)).BeginInit();
            this.xtraTabControl2.SuspendLayout();
            this.pageStation.SuspendLayout();
            this.pageSupplier.SuspendLayout();
            this.pagePurchase.SuspendLayout();
            this.pageSale.SuspendLayout();
            this.xtraTabPage3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcSupplier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            this.xtraTabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtLog.Properties)).BeginInit();
            this.xtraTabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).BeginInit();
            this.panelControl5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).BeginInit();
            this.groupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFileSaleOUT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSalePath.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBatch.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFilePurchaseOUT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tglCompraConfig.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPurchasePath.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tglVentaConfig.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkMesAnterior.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrecioCompra.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtNotifyTo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSSL.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPort.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSMTP.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMailTest.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTimeout.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSMTPUser.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSMPTPass.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkCrash.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAllLog.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkConfig.Properties)).BeginInit();
            this.xtraTabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(30, 27);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(66, 16);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "Servidores:";
            this.labelControl1.Click += new System.EventHandler(this.labelControl1_Click);
            // 
            // btnTestConection
            // 
            this.btnTestConection.Image = ((System.Drawing.Image)(resources.GetObject("btnTestConection.Image")));
            this.btnTestConection.Location = new System.Drawing.Point(350, 321);
            this.btnTestConection.Name = "btnTestConection";
            this.btnTestConection.Size = new System.Drawing.Size(168, 53);
            this.btnTestConection.TabIndex = 1;
            this.btnTestConection.Text = "Probar conexión";
            this.btnTestConection.ToolTip = "Revisar que el servidor de base de datos esté disponible.";
            this.btnTestConection.Click += new System.EventHandler(this.btnTestConection_Click);
            // 
            // lueServer
            // 
            this.lueServer.EditValue = "";
            this.lueServer.Location = new System.Drawing.Point(110, 24);
            this.lueServer.Name = "lueServer";
            this.lueServer.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.lueServer.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.lueServer.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lueServer.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("description", "Server")});
            this.lueServer.Properties.DisplayMember = "description";
            this.lueServer.Properties.ValueMember = "description";
            this.lueServer.Size = new System.Drawing.Size(229, 22);
            this.lueServer.TabIndex = 2;
            this.lueServer.EditValueChanged += new System.EventHandler(this.lueServer_EditValueChanged);
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.labelControl17);
            this.panelControl1.Controls.Add(this.labelControl16);
            this.panelControl1.Controls.Add(this.btnSaveServer);
            this.panelControl1.Controls.Add(this.lblPass);
            this.panelControl1.Controls.Add(this.txtConfirmPassword);
            this.panelControl1.Controls.Add(this.labelControl13);
            this.panelControl1.Controls.Add(this.txtConfigPlus);
            this.panelControl1.Controls.Add(this.labelControl14);
            this.panelControl1.Controls.Add(this.txtPassword);
            this.panelControl1.Controls.Add(this.labelControl12);
            this.panelControl1.Controls.Add(this.txtUsername);
            this.panelControl1.Controls.Add(this.labelControl11);
            this.panelControl1.Controls.Add(this.txtDatabase);
            this.panelControl1.Controls.Add(this.labelControl10);
            this.panelControl1.Controls.Add(this.txtIP);
            this.panelControl1.Controls.Add(this.labelControl9);
            this.panelControl1.Controls.Add(this.lueServer);
            this.panelControl1.Controls.Add(this.btnTestConection);
            this.panelControl1.Controls.Add(this.labelControl1);
            this.panelControl1.Controls.Add(this.luePlataforma);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1002, 601);
            this.panelControl1.TabIndex = 3;
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.Font = new System.Drawing.Font("Tahoma", 6.8F);
            this.labelControl17.Appearance.ForeColor = System.Drawing.Color.Silver;
            this.labelControl17.Appearance.Options.UseFont = true;
            this.labelControl17.Appearance.Options.UseForeColor = true;
            this.labelControl17.Location = new System.Drawing.Point(247, 283);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(155, 13);
            this.labelControl17.TabIndex = 27;
            this.labelControl17.Text = "(MultipleActiveResultSets=True)";
            this.labelControl17.Click += new System.EventHandler(this.labelControl17_Click);
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(104, 95);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(72, 16);
            this.labelControl16.TabIndex = 26;
            this.labelControl16.Text = "Dirección IP:";
            this.labelControl16.Click += new System.EventHandler(this.labelControl16_Click);
            // 
            // btnSaveServer
            // 
            this.btnSaveServer.Image = ((System.Drawing.Image)(resources.GetObject("btnSaveServer.Image")));
            this.btnSaveServer.Location = new System.Drawing.Point(850, 501);
            this.btnSaveServer.Name = "btnSaveServer";
            this.btnSaveServer.Size = new System.Drawing.Size(142, 74);
            this.btnSaveServer.TabIndex = 23;
            this.btnSaveServer.Text = "Grabar cambios";
            this.btnSaveServer.ToolTip = "Salvar los cambios de la configuración del servidor seleccionado.";
            this.btnSaveServer.Click += new System.EventHandler(this.btnSaveServer_Click);
            // 
            // lblPass
            // 
            this.lblPass.Appearance.Font = new System.Drawing.Font("Tahoma", 6.8F);
            this.lblPass.Appearance.ForeColor = System.Drawing.Color.Red;
            this.lblPass.Appearance.Options.UseFont = true;
            this.lblPass.Appearance.Options.UseForeColor = true;
            this.lblPass.Location = new System.Drawing.Point(247, 226);
            this.lblPass.Name = "lblPass";
            this.lblPass.Size = new System.Drawing.Size(0, 13);
            this.lblPass.TabIndex = 22;
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.EnterMoveNextControl = true;
            this.txtConfirmPassword.Location = new System.Drawing.Point(247, 202);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtConfirmPassword.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtConfirmPassword.Properties.PasswordChar = '*';
            this.txtConfirmPassword.Properties.UseSystemPasswordChar = true;
            this.txtConfirmPassword.Properties.ValidateOnEnterKey = true;
            this.txtConfirmPassword.Size = new System.Drawing.Size(271, 22);
            this.txtConfirmPassword.TabIndex = 21;
            this.txtConfirmPassword.EditValueChanged += new System.EventHandler(this.txtConfirmPassword_EditValueChanged);
            this.txtConfirmPassword.Leave += new System.EventHandler(this.txtConfirmPassword_Leave);
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(104, 205);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(129, 16);
            this.labelControl13.TabIndex = 20;
            this.labelControl13.Text = "Confirmar contraseña:";
            // 
            // txtConfigPlus
            // 
            this.txtConfigPlus.EnterMoveNextControl = true;
            this.txtConfigPlus.Location = new System.Drawing.Point(247, 255);
            this.txtConfigPlus.Name = "txtConfigPlus";
            this.txtConfigPlus.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtConfigPlus.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtConfigPlus.Size = new System.Drawing.Size(271, 22);
            this.txtConfigPlus.TabIndex = 19;
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(104, 257);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(137, 16);
            this.labelControl14.TabIndex = 18;
            this.labelControl14.Text = "Configuración adicional:";
            // 
            // txtPassword
            // 
            this.txtPassword.EnterMoveNextControl = true;
            this.txtPassword.Location = new System.Drawing.Point(247, 177);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtPassword.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtPassword.Properties.PasswordChar = '*';
            this.txtPassword.Properties.UseSystemPasswordChar = true;
            this.txtPassword.Properties.ValidateOnEnterKey = true;
            this.txtPassword.Size = new System.Drawing.Size(271, 22);
            this.txtPassword.TabIndex = 17;
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(104, 179);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(70, 16);
            this.labelControl12.TabIndex = 16;
            this.labelControl12.Text = "Contraseña:";
            // 
            // txtUsername
            // 
            this.txtUsername.EnterMoveNextControl = true;
            this.txtUsername.Location = new System.Drawing.Point(247, 148);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtUsername.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtUsername.Size = new System.Drawing.Size(271, 22);
            this.txtUsername.TabIndex = 15;
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(104, 150);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(48, 16);
            this.labelControl11.TabIndex = 14;
            this.labelControl11.Text = "Usuario:";
            // 
            // txtDatabase
            // 
            this.txtDatabase.EnterMoveNextControl = true;
            this.txtDatabase.Location = new System.Drawing.Point(247, 120);
            this.txtDatabase.Name = "txtDatabase";
            this.txtDatabase.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtDatabase.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtDatabase.Size = new System.Drawing.Size(271, 22);
            this.txtDatabase.TabIndex = 13;
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(104, 122);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(85, 16);
            this.labelControl10.TabIndex = 12;
            this.labelControl10.Text = "Base de datos:";
            // 
            // txtIP
            // 
            this.txtIP.EnterMoveNextControl = true;
            this.txtIP.Location = new System.Drawing.Point(247, 92);
            this.txtIP.Name = "txtIP";
            this.txtIP.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtIP.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtIP.Size = new System.Drawing.Size(271, 22);
            this.txtIP.TabIndex = 11;
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(535, 123);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(67, 16);
            this.labelControl9.TabIndex = 10;
            this.labelControl9.Text = "Plataforma:";
            this.labelControl9.Click += new System.EventHandler(this.labelControl9_Click);
            // 
            // luePlataforma
            // 
            this.luePlataforma.Location = new System.Drawing.Point(608, 119);
            this.luePlataforma.Name = "luePlataforma";
            this.luePlataforma.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.luePlataforma.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.luePlataforma.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.luePlataforma.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("platform", "Manejador de Base de datos")});
            this.luePlataforma.Properties.DisplayMember = "platform";
            this.luePlataforma.Properties.NullText = "";
            this.luePlataforma.Properties.ValueMember = "platform";
            this.luePlataforma.Size = new System.Drawing.Size(147, 22);
            this.luePlataforma.TabIndex = 25;
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 0);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage7;
            this.xtraTabControl1.Size = new System.Drawing.Size(1009, 651);
            this.xtraTabControl1.TabIndex = 4;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage7,
            this.xtraTabPage1,
            this.xtraTabPage2,
            this.xtraTabPage3,
            this.xtraTabPage4,
            this.xtraTabPage5,
            this.xtraTabPage6});
            this.xtraTabControl1.SelectedPageChanged += new DevExpress.XtraTab.TabPageChangedEventHandler(this.xtraTabControl1_SelectedPageChanged);
            // 
            // xtraTabPage7
            // 
            this.xtraTabPage7.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage7.Image")));
            this.xtraTabPage7.Name = "xtraTabPage7";
            this.xtraTabPage7.Size = new System.Drawing.Size(1002, 601);
            this.xtraTabPage7.Text = "Excepciones";
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.panelControl1);
            this.xtraTabPage1.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage1.Image")));
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(1002, 601);
            this.xtraTabPage1.Text = "Servidores";
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.xtraTabControl2);
            this.xtraTabPage2.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage2.Image")));
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(1002, 601);
            this.xtraTabPage2.Text = "Procesos";
            // 
            // xtraTabControl2
            // 
            this.xtraTabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl2.HeaderLocation = DevExpress.XtraTab.TabHeaderLocation.Left;
            this.xtraTabControl2.Location = new System.Drawing.Point(0, 0);
            this.xtraTabControl2.Name = "xtraTabControl2";
            this.xtraTabControl2.SelectedTabPage = this.pageStation;
            this.xtraTabControl2.Size = new System.Drawing.Size(1002, 601);
            this.xtraTabControl2.TabIndex = 1;
            this.xtraTabControl2.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.pageStation,
            this.pageSupplier,
            this.pagePurchase,
            this.pageSale});
            this.xtraTabControl2.Tag = "";
            // 
            // pageStation
            // 
            this.pageStation.Controls.Add(this.ctrlProcessStation);
            this.pageStation.Image = ((System.Drawing.Image)(resources.GetObject("pageStation.Image")));
            this.pageStation.Name = "pageStation";
            this.pageStation.Size = new System.Drawing.Size(952, 594);
            this.pageStation.Tag = "ESTACIONES";
            this.pageStation.Text = "Estaciones";
            this.pageStation.Tooltip = "Configurar el orígen de las estaciones";
            // 
            // ctrlProcessStation
            // 
            this.ctrlProcessStation.AutoSize = true;
            this.ctrlProcessStation.changeProcess = false;
            this.ctrlProcessStation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlProcessStation.Location = new System.Drawing.Point(0, 0);
            this.ctrlProcessStation.Name = "ctrlProcessStation";
            this.ctrlProcessStation.Size = new System.Drawing.Size(952, 594);
            this.ctrlProcessStation.TabIndex = 0;
            // 
            // pageSupplier
            // 
            this.pageSupplier.Controls.Add(this.ctrlProcessSupplier);
            this.pageSupplier.Image = ((System.Drawing.Image)(resources.GetObject("pageSupplier.Image")));
            this.pageSupplier.Name = "pageSupplier";
            this.pageSupplier.Size = new System.Drawing.Size(952, 594);
            this.pageSupplier.Tag = "PROVEEDORES";
            this.pageSupplier.Text = "Proveedores";
            this.pageSupplier.Tooltip = "Configurar el orígen de los proveedores, puede ser un archivo Json, CSV, XLSX o u" +
    "n query de base de datos";
            // 
            // ctrlProcessSupplier
            // 
            this.ctrlProcessSupplier.AutoSize = true;
            this.ctrlProcessSupplier.changeProcess = false;
            this.ctrlProcessSupplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlProcessSupplier.Location = new System.Drawing.Point(0, 0);
            this.ctrlProcessSupplier.Name = "ctrlProcessSupplier";
            this.ctrlProcessSupplier.Size = new System.Drawing.Size(952, 594);
            this.ctrlProcessSupplier.TabIndex = 0;
            // 
            // pagePurchase
            // 
            this.pagePurchase.Controls.Add(this.ctrlProcessPurchase);
            this.pagePurchase.Image = ((System.Drawing.Image)(resources.GetObject("pagePurchase.Image")));
            this.pagePurchase.Name = "pagePurchase";
            this.pagePurchase.Size = new System.Drawing.Size(952, 594);
            this.pagePurchase.Tag = "COMPRAS";
            this.pagePurchase.Text = "Compras";
            this.pagePurchase.Tooltip = "Origen de datos para las compras";
            // 
            // ctrlProcessPurchase
            // 
            this.ctrlProcessPurchase.AutoSize = true;
            this.ctrlProcessPurchase.changeProcess = false;
            this.ctrlProcessPurchase.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlProcessPurchase.getsetLog = null;
            this.ctrlProcessPurchase.Location = new System.Drawing.Point(0, 0);
            this.ctrlProcessPurchase.Name = "ctrlProcessPurchase";
            this.ctrlProcessPurchase.Size = new System.Drawing.Size(952, 594);
            this.ctrlProcessPurchase.TabIndex = 1;
            this.ctrlProcessPurchase.Load += new System.EventHandler(this.ctrlProcessPurchase_Load);
            // 
            // pageSale
            // 
            this.pageSale.Controls.Add(this.ctrlProcessSale);
            this.pageSale.Image = ((System.Drawing.Image)(resources.GetObject("pageSale.Image")));
            this.pageSale.Name = "pageSale";
            this.pageSale.Size = new System.Drawing.Size(952, 594);
            this.pageSale.Tag = "VENTAS";
            this.pageSale.Text = "Ventas";
            this.pageSale.Tooltip = "Origen de datos para las Ventas";
            // 
            // ctrlProcessSale
            // 
            this.ctrlProcessSale.AutoSize = true;
            this.ctrlProcessSale.changeProcess = false;
            this.ctrlProcessSale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ctrlProcessSale.Location = new System.Drawing.Point(0, 0);
            this.ctrlProcessSale.Name = "ctrlProcessSale";
            this.ctrlProcessSale.Size = new System.Drawing.Size(952, 594);
            this.ctrlProcessSale.TabIndex = 1;
            // 
            // xtraTabPage3
            // 
            this.xtraTabPage3.Controls.Add(this.tableLayoutPanel1);
            this.xtraTabPage3.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage3.Image")));
            this.xtraTabPage3.Name = "xtraTabPage3";
            this.xtraTabPage3.Size = new System.Drawing.Size(1002, 601);
            this.xtraTabPage3.Text = "Proveedores";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.gcSupplier, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panelControl2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1253, 751);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // gcSupplier
            // 
            this.gcSupplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcSupplier.Location = new System.Drawing.Point(3, 3);
            this.gcSupplier.MainView = this.gridView1;
            this.gcSupplier.Name = "gcSupplier";
            this.gcSupplier.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit1});
            this.gcSupplier.Size = new System.Drawing.Size(1247, 686);
            this.gcSupplier.TabIndex = 1;
            this.gcSupplier.UseEmbeddedNavigator = true;
            this.gcSupplier.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5});
            this.gridView1.GridControl = this.gcSupplier;
            this.gridView1.Name = "gridView1";
            this.gridView1.NewItemRowText = "Agregar nuevo Proveedor";
            this.gridView1.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.False;
            this.gridView1.OptionsBehavior.ReadOnly = true;
            this.gridView1.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView1.OptionsView.EnableAppearanceOddRow = true;
            this.gridView1.OptionsView.RowAutoHeight = true;
            // 
            // gridColumn1
            // 
            this.gridColumn1.FieldName = "id";
            this.gridColumn1.Fixed = DevExpress.XtraGrid.Columns.FixedStyle.Left;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.OptionsColumn.FixedWidth = true;
            this.gridColumn1.OptionsColumn.ReadOnly = true;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 84;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Nombre del Proveedor";
            this.gridColumn2.ColumnEdit = this.repositoryItemTextEdit1;
            this.gridColumn2.FieldName = "nombre";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 203;
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "RFC";
            this.gridColumn3.ColumnEdit = this.repositoryItemTextEdit1;
            this.gridColumn3.FieldName = "rfc";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            this.gridColumn3.Width = 203;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "Permiso 1";
            this.gridColumn4.ColumnEdit = this.repositoryItemTextEdit1;
            this.gridColumn4.FieldName = "permiso1";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            this.gridColumn4.Width = 203;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "Permiso 2";
            this.gridColumn5.ColumnEdit = this.repositoryItemTextEdit1;
            this.gridColumn5.FieldName = "permiso2";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 4;
            this.gridColumn5.Width = 209;
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.btnSupplier);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl2.Location = new System.Drawing.Point(3, 695);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(1247, 53);
            this.panelControl2.TabIndex = 2;
            // 
            // btnSupplier
            // 
            this.btnSupplier.Image = ((System.Drawing.Image)(resources.GetObject("btnSupplier.Image")));
            this.btnSupplier.Location = new System.Drawing.Point(849, 9);
            this.btnSupplier.Name = "btnSupplier";
            this.btnSupplier.Size = new System.Drawing.Size(139, 32);
            this.btnSupplier.TabIndex = 2;
            this.btnSupplier.Text = "Agregar proveedor";
            this.btnSupplier.ToolTip = "Agregar un proveedor nuevo.";
            this.btnSupplier.Click += new System.EventHandler(this.btnSupplier_Click);
            // 
            // xtraTabPage4
            // 
            this.xtraTabPage4.Controls.Add(this.panelControl3);
            this.xtraTabPage4.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage4.Image")));
            this.xtraTabPage4.Name = "xtraTabPage4";
            this.xtraTabPage4.Size = new System.Drawing.Size(1002, 601);
            this.xtraTabPage4.Text = "Bitacora de Actividades";
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.btnRefreshLog);
            this.panelControl3.Controls.Add(this.lblModify);
            this.panelControl3.Controls.Add(this.labelControl2);
            this.panelControl3.Controls.Add(this.txtLog);
            this.panelControl3.Controls.Add(this.labelControl4);
            this.panelControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl3.Location = new System.Drawing.Point(0, 0);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(1002, 601);
            this.panelControl3.TabIndex = 0;
            // 
            // btnRefreshLog
            // 
            this.btnRefreshLog.Image = ((System.Drawing.Image)(resources.GetObject("btnRefreshLog.Image")));
            this.btnRefreshLog.Location = new System.Drawing.Point(885, 546);
            this.btnRefreshLog.Name = "btnRefreshLog";
            this.btnRefreshLog.Size = new System.Drawing.Size(111, 45);
            this.btnRefreshLog.TabIndex = 13;
            this.btnRefreshLog.Text = "Actualizar";
            this.btnRefreshLog.ToolTip = "Agregar un proveedor nuevo.";
            this.btnRefreshLog.Click += new System.EventHandler(this.btnRefreshLog_Click);
            // 
            // lblModify
            // 
            this.lblModify.Location = new System.Drawing.Point(780, 38);
            this.lblModify.Name = "lblModify";
            this.lblModify.Size = new System.Drawing.Size(4, 16);
            this.lblModify.TabIndex = 12;
            this.lblModify.Text = ".";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(658, 38);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(116, 16);
            this.labelControl2.TabIndex = 11;
            this.labelControl2.Text = "Última modificación:";
            // 
            // txtLog
            // 
            this.txtLog.Location = new System.Drawing.Point(34, 60);
            this.txtLog.Name = "txtLog";
            this.txtLog.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtLog.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtLog.Properties.AppearanceReadOnly.BackColor = System.Drawing.SystemColors.Info;
            this.txtLog.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.txtLog.Properties.ReadOnly = true;
            this.txtLog.Properties.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLog.Properties.WordWrap = false;
            this.txtLog.Size = new System.Drawing.Size(962, 480);
            this.txtLog.TabIndex = 10;
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(34, 38);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(64, 16);
            this.labelControl4.TabIndex = 9;
            this.labelControl4.Text = "Actividades";
            this.labelControl4.Click += new System.EventHandler(this.labelControl4_Click);
            // 
            // xtraTabPage5
            // 
            this.xtraTabPage5.Controls.Add(this.panelControl5);
            this.xtraTabPage5.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage5.Image")));
            this.xtraTabPage5.Name = "xtraTabPage5";
            this.xtraTabPage5.Size = new System.Drawing.Size(1002, 601);
            this.xtraTabPage5.Text = "Sistema";
            // 
            // panelControl5
            // 
            this.panelControl5.Controls.Add(this.groupControl4);
            this.panelControl5.Controls.Add(this.groupControl3);
            this.panelControl5.Controls.Add(this.groupControl2);
            this.panelControl5.Controls.Add(this.groupControl1);
            this.panelControl5.Controls.Add(this.btnChangeSystem);
            this.panelControl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl5.Location = new System.Drawing.Point(0, 0);
            this.panelControl5.Name = "panelControl5";
            this.panelControl5.Size = new System.Drawing.Size(1253, 751);
            this.panelControl5.TabIndex = 0;
            // 
            // groupControl4
            // 
            this.groupControl4.CaptionImage = ((System.Drawing.Image)(resources.GetObject("groupControl4.CaptionImage")));
            this.groupControl4.Controls.Add(this.labelControl24);
            this.groupControl4.Controls.Add(this.simpleButton1);
            this.groupControl4.Controls.Add(this.txtFileSaleOUT);
            this.groupControl4.Controls.Add(this.txtSalePath);
            this.groupControl4.Controls.Add(this.labelControl23);
            this.groupControl4.Controls.Add(this.chkBatch);
            this.groupControl4.Controls.Add(this.txtFilePurchaseOUT);
            this.groupControl4.Controls.Add(this.btnPath);
            this.groupControl4.Controls.Add(this.tglCompraConfig);
            this.groupControl4.Controls.Add(this.txtPurchasePath);
            this.groupControl4.Controls.Add(this.tglVentaConfig);
            this.groupControl4.Location = new System.Drawing.Point(514, 19);
            this.groupControl4.Name = "groupControl4";
            this.groupControl4.Size = new System.Drawing.Size(469, 279);
            this.groupControl4.TabIndex = 56;
            this.groupControl4.Text = "Destino de salida de resultados";
            // 
            // labelControl24
            // 
            this.labelControl24.Location = new System.Drawing.Point(20, 244);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(145, 16);
            this.labelControl24.TabIndex = 54;
            this.labelControl24.Text = "Archivo de salida Ventas:";
            // 
            // simpleButton1
            // 
            this.simpleButton1.Enabled = false;
            this.simpleButton1.Location = new System.Drawing.Point(414, 209);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(32, 25);
            this.simpleButton1.TabIndex = 57;
            this.simpleButton1.Text = "...";
            // 
            // txtFileSaleOUT
            // 
            this.txtFileSaleOUT.EditValue = "{station}_yyyyMMdd_{period}_ventas";
            this.txtFileSaleOUT.Enabled = false;
            this.txtFileSaleOUT.EnterMoveNextControl = true;
            this.txtFileSaleOUT.Location = new System.Drawing.Point(189, 241);
            this.txtFileSaleOUT.Name = "txtFileSaleOUT";
            this.txtFileSaleOUT.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtFileSaleOUT.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtFileSaleOUT.Size = new System.Drawing.Size(257, 22);
            this.txtFileSaleOUT.TabIndex = 55;
            this.txtFileSaleOUT.ToolTip = "Posibles opciones:\r\n\r\n{estacion}\r\n{centrocostos}\r\n{periodo}\r\n\r\nyyyy - Año \r\nMM - " +
    "Mes\r\ndd - día\r\n\r\nla extensión se define a partir del destino de los resultados";
            // 
            // txtSalePath
            // 
            this.txtSalePath.EditValue = "Ruta donde se grabarán los scripts de Ventas";
            this.txtSalePath.Enabled = false;
            this.txtSalePath.Location = new System.Drawing.Point(20, 210);
            this.txtSalePath.Name = "txtSalePath";
            this.txtSalePath.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtSalePath.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtSalePath.Properties.NullText = "Ruta de trabajo donde se grabaran los scripts de compras";
            this.txtSalePath.Properties.NullValuePrompt = "Ruta de trabajo donde se grabaran los scripts de compras";
            this.txtSalePath.Size = new System.Drawing.Size(392, 22);
            this.txtSalePath.TabIndex = 56;
            // 
            // labelControl23
            // 
            this.labelControl23.Location = new System.Drawing.Point(20, 139);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(163, 16);
            this.labelControl23.TabIndex = 51;
            this.labelControl23.Text = "Archivos de salida Compras:";
            // 
            // chkBatch
            // 
            this.chkBatch.Enabled = false;
            this.chkBatch.Location = new System.Drawing.Point(20, 45);
            this.chkBatch.Name = "chkBatch";
            this.chkBatch.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.chkBatch.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.chkBatch.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Default;
            this.chkBatch.Properties.Caption = "Integrar scripts en archivos de procesamiento por lotes";
            this.chkBatch.Size = new System.Drawing.Size(391, 20);
            this.chkBatch.TabIndex = 53;
            // 
            // txtFilePurchaseOUT
            // 
            this.txtFilePurchaseOUT.EditValue = "{station}_yyyyMMdd_{period}_compras";
            this.txtFilePurchaseOUT.Enabled = false;
            this.txtFilePurchaseOUT.EnterMoveNextControl = true;
            this.txtFilePurchaseOUT.Location = new System.Drawing.Point(189, 136);
            this.txtFilePurchaseOUT.Name = "txtFilePurchaseOUT";
            this.txtFilePurchaseOUT.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtFilePurchaseOUT.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtFilePurchaseOUT.Size = new System.Drawing.Size(257, 22);
            this.txtFilePurchaseOUT.TabIndex = 52;
            this.txtFilePurchaseOUT.ToolTip = "Posibles opciones:\r\n\r\n{estacion}\r\n{centrocostos}\r\n{periodo}\r\n\r\nyyyy - Año \r\nMM - " +
    "Mes\r\ndd - día\r\n\r\nla extensión se define a partir del destino de los resultados";
            this.txtFilePurchaseOUT.ToolTipIconType = DevExpress.Utils.ToolTipIconType.Information;
            // 
            // btnPath
            // 
            this.btnPath.Enabled = false;
            this.btnPath.Location = new System.Drawing.Point(414, 108);
            this.btnPath.Name = "btnPath";
            this.btnPath.Size = new System.Drawing.Size(32, 25);
            this.btnPath.TabIndex = 55;
            this.btnPath.Text = "...";
            // 
            // tglCompraConfig
            // 
            this.tglCompraConfig.EditValue = true;
            this.tglCompraConfig.Location = new System.Drawing.Point(20, 78);
            this.tglCompraConfig.Name = "tglCompraConfig";
            this.tglCompraConfig.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Default;
            this.tglCompraConfig.Properties.OffText = "Procesar Compras y generar Script SQL";
            this.tglCompraConfig.Properties.OnText = "Procesar Compras e insertar directo en EDS";
            this.tglCompraConfig.Size = new System.Drawing.Size(374, 26);
            this.tglCompraConfig.TabIndex = 51;
            this.tglCompraConfig.Toggled += new System.EventHandler(this.tglCompraConfig_Toggled);
            // 
            // txtPurchasePath
            // 
            this.txtPurchasePath.EditValue = "Ruta donde se grabarán los scripts de Compras";
            this.txtPurchasePath.Enabled = false;
            this.txtPurchasePath.Location = new System.Drawing.Point(20, 109);
            this.txtPurchasePath.Name = "txtPurchasePath";
            this.txtPurchasePath.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtPurchasePath.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtPurchasePath.Properties.NullText = "Ruta de trabajo donde se grabaran los scripts de compras";
            this.txtPurchasePath.Properties.NullValuePrompt = "Ruta de trabajo donde se grabaran los scripts de compras";
            this.txtPurchasePath.Size = new System.Drawing.Size(392, 22);
            this.txtPurchasePath.TabIndex = 54;
            // 
            // tglVentaConfig
            // 
            this.tglVentaConfig.EditValue = true;
            this.tglVentaConfig.Location = new System.Drawing.Point(20, 180);
            this.tglVentaConfig.Name = "tglVentaConfig";
            this.tglVentaConfig.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Default;
            this.tglVentaConfig.Properties.OffText = "Procesar Ventas y generar Script SQL";
            this.tglVentaConfig.Properties.OnText = "Procesar Ventas e insertar directo en EDS";
            this.tglVentaConfig.Size = new System.Drawing.Size(374, 26);
            this.tglVentaConfig.TabIndex = 52;
            this.tglVentaConfig.Toggled += new System.EventHandler(this.tglVentaConfig_Toggled);
            // 
            // groupControl3
            // 
            this.groupControl3.CaptionImage = ((System.Drawing.Image)(resources.GetObject("groupControl3.CaptionImage")));
            this.groupControl3.Controls.Add(this.chkMesAnterior);
            this.groupControl3.Controls.Add(this.txtPrecioCompra);
            this.groupControl3.Controls.Add(this.labelControl22);
            this.groupControl3.Location = new System.Drawing.Point(514, 322);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(469, 101);
            this.groupControl3.TabIndex = 55;
            this.groupControl3.Text = "Criterios generales";
            // 
            // chkMesAnterior
            // 
            this.chkMesAnterior.EditValue = null;
            this.chkMesAnterior.Location = new System.Drawing.Point(20, 66);
            this.chkMesAnterior.Name = "chkMesAnterior";
            this.chkMesAnterior.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.chkMesAnterior.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.chkMesAnterior.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Default;
            this.chkMesAnterior.Properties.Caption = "Procesar compras del mes inmediato anterior ";
            this.chkMesAnterior.Size = new System.Drawing.Size(284, 20);
            this.chkMesAnterior.TabIndex = 50;
            // 
            // txtPrecioCompra
            // 
            this.txtPrecioCompra.EditValue = new decimal(new int[] {
            22,
            0,
            0,
            0});
            this.txtPrecioCompra.Location = new System.Drawing.Point(318, 36);
            this.txtPrecioCompra.Name = "txtPrecioCompra";
            this.txtPrecioCompra.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtPrecioCompra.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtPrecioCompra.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtPrecioCompra.Size = new System.Drawing.Size(106, 22);
            this.txtPrecioCompra.TabIndex = 32;
            // 
            // labelControl22
            // 
            this.labelControl22.Location = new System.Drawing.Point(20, 39);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(214, 16);
            this.labelControl22.TabIndex = 31;
            this.labelControl22.Text = "Ignorar compras con precio mayor a:";
            // 
            // groupControl2
            // 
            this.groupControl2.CaptionImage = ((System.Drawing.Image)(resources.GetObject("groupControl2.CaptionImage")));
            this.groupControl2.Controls.Add(this.labelControl5);
            this.groupControl2.Controls.Add(this.labelControl21);
            this.groupControl2.Controls.Add(this.txtNotifyTo);
            this.groupControl2.Controls.Add(this.labelControl20);
            this.groupControl2.Controls.Add(this.chkSSL);
            this.groupControl2.Controls.Add(this.txtPort);
            this.groupControl2.Controls.Add(this.labelControl8);
            this.groupControl2.Controls.Add(this.txtSMTP);
            this.groupControl2.Controls.Add(this.labelControl3);
            this.groupControl2.Controls.Add(this.labelControl19);
            this.groupControl2.Controls.Add(this.txtMailTest);
            this.groupControl2.Controls.Add(this.labelControl18);
            this.groupControl2.Controls.Add(this.txtTimeout);
            this.groupControl2.Controls.Add(this.txtSMTPUser);
            this.groupControl2.Controls.Add(this.labelControl15);
            this.groupControl2.Controls.Add(this.btnTestSMTP);
            this.groupControl2.Controls.Add(this.txtSMPTPass);
            this.groupControl2.Controls.Add(this.labelControl7);
            this.groupControl2.Controls.Add(this.labelControl6);
            this.groupControl2.Location = new System.Drawing.Point(11, 14);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(445, 549);
            this.groupControl2.TabIndex = 54;
            this.groupControl2.Text = "Configurar Notificaciones";
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(27, 55);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(53, 16);
            this.labelControl5.TabIndex = 40;
            this.labelControl5.Text = "Servidor:";
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.Font = new System.Drawing.Font("Tahoma", 6.8F);
            this.labelControl21.Appearance.ForeColor = System.Drawing.Color.Silver;
            this.labelControl21.Appearance.Options.UseFont = true;
            this.labelControl21.Appearance.Options.UseForeColor = true;
            this.labelControl21.Location = new System.Drawing.Point(140, 518);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(67, 13);
            this.labelControl21.TabIndex = 53;
            this.labelControl21.Text = "separador ( ;)";
            // 
            // txtNotifyTo
            // 
            this.txtNotifyTo.Location = new System.Drawing.Point(140, 366);
            this.txtNotifyTo.Name = "txtNotifyTo";
            this.txtNotifyTo.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtNotifyTo.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtNotifyTo.Size = new System.Drawing.Size(271, 146);
            this.txtNotifyTo.TabIndex = 52;
            // 
            // labelControl20
            // 
            this.labelControl20.Location = new System.Drawing.Point(27, 368);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(63, 16);
            this.labelControl20.TabIndex = 51;
            this.labelControl20.Text = "Notificar a:";
            // 
            // chkSSL
            // 
            this.chkSSL.EditValue = null;
            this.chkSSL.Location = new System.Drawing.Point(141, 202);
            this.chkSSL.Name = "chkSSL";
            this.chkSSL.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.chkSSL.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.chkSSL.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Default;
            this.chkSSL.Properties.Caption = "Habilitar conexión segura (SSL)";
            this.chkSSL.Size = new System.Drawing.Size(218, 20);
            this.chkSSL.TabIndex = 44;
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(140, 80);
            this.txtPort.Name = "txtPort";
            this.txtPort.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtPort.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtPort.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtPort.Size = new System.Drawing.Size(106, 22);
            this.txtPort.TabIndex = 30;
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 6.8F);
            this.labelControl8.Appearance.ForeColor = System.Drawing.Color.Silver;
            this.labelControl8.Appearance.Options.UseFont = true;
            this.labelControl8.Appearance.Options.UseForeColor = true;
            this.labelControl8.Location = new System.Drawing.Point(141, 266);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(67, 13);
            this.labelControl8.TabIndex = 48;
            this.labelControl8.Text = "separador ( ;)";
            // 
            // txtSMTP
            // 
            this.txtSMTP.EnterMoveNextControl = true;
            this.txtSMTP.Location = new System.Drawing.Point(140, 52);
            this.txtSMTP.Name = "txtSMTP";
            this.txtSMTP.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtSMTP.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtSMTP.Size = new System.Drawing.Size(271, 22);
            this.txtSMTP.TabIndex = 28;
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(27, 243);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(106, 16);
            this.labelControl3.TabIndex = 47;
            this.labelControl3.Text = "Correo de prueba:";
            // 
            // labelControl19
            // 
            this.labelControl19.Location = new System.Drawing.Point(27, 83);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(42, 16);
            this.labelControl19.TabIndex = 29;
            this.labelControl19.Text = "Puerto:";
            // 
            // txtMailTest
            // 
            this.txtMailTest.EnterMoveNextControl = true;
            this.txtMailTest.Location = new System.Drawing.Point(140, 240);
            this.txtMailTest.Name = "txtMailTest";
            this.txtMailTest.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtMailTest.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtMailTest.Size = new System.Drawing.Size(271, 22);
            this.txtMailTest.TabIndex = 46;
            // 
            // labelControl18
            // 
            this.labelControl18.Location = new System.Drawing.Point(27, 118);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(48, 16);
            this.labelControl18.TabIndex = 31;
            this.labelControl18.Text = "Usuario:";
            // 
            // txtTimeout
            // 
            this.txtTimeout.EditValue = new decimal(new int[] {
            587,
            0,
            0,
            0});
            this.txtTimeout.Location = new System.Drawing.Point(140, 174);
            this.txtTimeout.Name = "txtTimeout";
            this.txtTimeout.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtTimeout.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtTimeout.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtTimeout.Properties.Precision = 4;
            this.txtTimeout.Size = new System.Drawing.Size(106, 22);
            this.txtTimeout.TabIndex = 45;
            this.txtTimeout.EditValueChanged += new System.EventHandler(this.txtTimeout_EditValueChanged_1);
            // 
            // txtSMTPUser
            // 
            this.txtSMTPUser.EnterMoveNextControl = true;
            this.txtSMTPUser.Location = new System.Drawing.Point(140, 115);
            this.txtSMTPUser.Name = "txtSMTPUser";
            this.txtSMTPUser.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtSMTPUser.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtSMTPUser.Size = new System.Drawing.Size(271, 22);
            this.txtSMTPUser.TabIndex = 32;
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(27, 152);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(70, 16);
            this.labelControl15.TabIndex = 33;
            this.labelControl15.Text = "Contraseña:";
            // 
            // btnTestSMTP
            // 
            this.btnTestSMTP.Image = ((System.Drawing.Image)(resources.GetObject("btnTestSMTP.Image")));
            this.btnTestSMTP.Location = new System.Drawing.Point(140, 285);
            this.btnTestSMTP.Name = "btnTestSMTP";
            this.btnTestSMTP.Size = new System.Drawing.Size(152, 43);
            this.btnTestSMTP.TabIndex = 42;
            this.btnTestSMTP.Text = "Correo de prueba";
            this.btnTestSMTP.ToolTip = "Revisar que el servidor de base de datos esté disponible.";
            this.btnTestSMTP.Click += new System.EventHandler(this.btnTestSMTP_Click);
            // 
            // txtSMPTPass
            // 
            this.txtSMPTPass.EnterMoveNextControl = true;
            this.txtSMPTPass.Location = new System.Drawing.Point(140, 149);
            this.txtSMPTPass.Name = "txtSMPTPass";
            this.txtSMPTPass.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtSMPTPass.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtSMPTPass.Properties.UseSystemPasswordChar = true;
            this.txtSMPTPass.Properties.ValidateOnEnterKey = true;
            this.txtSMPTPass.Size = new System.Drawing.Size(271, 22);
            this.txtSMPTPass.TabIndex = 34;
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(27, 177);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(109, 16);
            this.labelControl7.TabIndex = 37;
            this.labelControl7.Text = "Tiempo de espera:";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 6.8F);
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl6.Appearance.Options.UseFont = true;
            this.labelControl6.Appearance.Options.UseForeColor = true;
            this.labelControl6.Location = new System.Drawing.Point(140, 182);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(0, 13);
            this.labelControl6.TabIndex = 39;
            // 
            // groupControl1
            // 
            this.groupControl1.CaptionImage = ((System.Drawing.Image)(resources.GetObject("groupControl1.CaptionImage")));
            this.groupControl1.Controls.Add(this.chkCrash);
            this.groupControl1.Controls.Add(this.chkAllLog);
            this.groupControl1.Controls.Add(this.chkConfig);
            this.groupControl1.Location = new System.Drawing.Point(514, 438);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(288, 126);
            this.groupControl1.TabIndex = 50;
            this.groupControl1.Text = "Alertas";
            // 
            // chkCrash
            // 
            this.chkCrash.EditValue = null;
            this.chkCrash.Location = new System.Drawing.Point(20, 94);
            this.chkCrash.Name = "chkCrash";
            this.chkCrash.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.chkCrash.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.chkCrash.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Default;
            this.chkCrash.Properties.Caption = "Reportar fallas durante el proceso";
            this.chkCrash.Size = new System.Drawing.Size(257, 20);
            this.chkCrash.TabIndex = 51;
            // 
            // chkAllLog
            // 
            this.chkAllLog.EditValue = null;
            this.chkAllLog.Location = new System.Drawing.Point(20, 65);
            this.chkAllLog.Name = "chkAllLog";
            this.chkAllLog.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.chkAllLog.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.chkAllLog.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Default;
            this.chkAllLog.Properties.Caption = "Reportar toda la actividad al concluir ";
            this.chkAllLog.Size = new System.Drawing.Size(257, 20);
            this.chkAllLog.TabIndex = 50;
            // 
            // chkConfig
            // 
            this.chkConfig.EditValue = null;
            this.chkConfig.Location = new System.Drawing.Point(20, 37);
            this.chkConfig.Name = "chkConfig";
            this.chkConfig.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.chkConfig.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.chkConfig.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Default;
            this.chkConfig.Properties.Caption = "Notificar cambios en la configuración";
            this.chkConfig.Size = new System.Drawing.Size(257, 20);
            this.chkConfig.TabIndex = 49;
            // 
            // btnChangeSystem
            // 
            this.btnChangeSystem.Image = ((System.Drawing.Image)(resources.GetObject("btnChangeSystem.Image")));
            this.btnChangeSystem.Location = new System.Drawing.Point(841, 489);
            this.btnChangeSystem.Name = "btnChangeSystem";
            this.btnChangeSystem.Size = new System.Drawing.Size(142, 74);
            this.btnChangeSystem.TabIndex = 43;
            this.btnChangeSystem.Text = "Grabar cambios";
            this.btnChangeSystem.ToolTip = "Salvar los cambios de la configuración del servidor seleccionado.";
            this.btnChangeSystem.Click += new System.EventHandler(this.btnChangeSystem_Click);
            // 
            // xtraTabPage6
            // 
            this.xtraTabPage6.Controls.Add(this.panelControl4);
            this.xtraTabPage6.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage6.Image")));
            this.xtraTabPage6.Name = "xtraTabPage6";
            this.xtraTabPage6.Size = new System.Drawing.Size(1002, 601);
            this.xtraTabPage6.Text = "Ayuda";
            // 
            // panelControl4
            // 
            this.panelControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl4.Location = new System.Drawing.Point(0, 0);
            this.panelControl4.Name = "panelControl4";
            this.panelControl4.Size = new System.Drawing.Size(1002, 601);
            this.panelControl4.TabIndex = 0;
            // 
            // frmConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 651);
            this.Controls.Add(this.xtraTabControl1);
            this.MaximizeBox = false;
            this.Name = "frmConfig";
            this.Text = "Configuración Avanzada Automatización JSON";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmConfig_FormClosing);
            this.Load += new System.EventHandler(this.frmConfig_Load);
            ((System.ComponentModel.ISupportInitialize)(this.lueServer.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtConfirmPassword.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtConfigPlus.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPassword.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUsername.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDatabase.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIP.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.luePlataforma.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            this.xtraTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl2)).EndInit();
            this.xtraTabControl2.ResumeLayout(false);
            this.pageStation.ResumeLayout(false);
            this.pageStation.PerformLayout();
            this.pageSupplier.ResumeLayout(false);
            this.pageSupplier.PerformLayout();
            this.pagePurchase.ResumeLayout(false);
            this.pagePurchase.PerformLayout();
            this.pageSale.ResumeLayout(false);
            this.pageSale.PerformLayout();
            this.xtraTabPage3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcSupplier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            this.xtraTabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtLog.Properties)).EndInit();
            this.xtraTabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).EndInit();
            this.panelControl5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).EndInit();
            this.groupControl4.ResumeLayout(false);
            this.groupControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtFileSaleOUT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSalePath.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkBatch.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFilePurchaseOUT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tglCompraConfig.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPurchasePath.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tglVentaConfig.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            this.groupControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkMesAnterior.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrecioCompra.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtNotifyTo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSSL.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPort.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSMTP.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMailTest.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTimeout.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSMTPUser.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSMPTPass.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chkCrash.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkAllLog.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkConfig.Properties)).EndInit();
            this.xtraTabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SimpleButton btnTestConection;
        private DevExpress.XtraEditors.LookUpEdit lueServer;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage3;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage4;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage5;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private DevExpress.XtraGrid.GridControl gcSupplier;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl2;
        private DevExpress.XtraTab.XtraTabPage pageStation;
        private DevExpress.XtraTab.XtraTabPage pageSupplier;
        private DevExpress.XtraTab.XtraTabPage pagePurchase;
        private DevExpress.XtraTab.XtraTabPage pageSale;
        private DevExpress.XtraEditors.TextEdit txtIP;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.SimpleButton btnSaveServer;
        private DevExpress.XtraEditors.LabelControl lblPass;
        private DevExpress.XtraEditors.TextEdit txtConfirmPassword;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit txtConfigPlus;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit txtPassword;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.TextEdit txtUsername;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit txtDatabase;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LookUpEdit luePlataforma;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private Utils.ctrlProcess ctrlProcessSupplier;
        private Utils.ctrlProcess ctrlProcessStation;
        private DevExpress.XtraEditors.SimpleButton btnSupplier;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        public DevExpress.XtraEditors.MemoEdit txtLog;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl lblModify;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.SimpleButton btnRefreshLog;
        private DevExpress.XtraEditors.PanelControl panelControl4;
        private DevExpress.XtraEditors.PanelControl panelControl5;
        private DevExpress.XtraEditors.SimpleButton btnChangeSystem;
        private DevExpress.XtraEditors.SimpleButton btnTestSMTP;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.TextEdit txtSMPTPass;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.TextEdit txtSMTPUser;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.TextEdit txtSMTP;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.CalcEdit txtPort;
        private DevExpress.XtraEditors.CheckEdit chkSSL;
        private DevExpress.XtraEditors.CalcEdit txtTimeout;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit txtMailTest;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.CheckEdit chkCrash;
        private DevExpress.XtraEditors.CheckEdit chkAllLog;
        private DevExpress.XtraEditors.CheckEdit chkConfig;
        private DevExpress.XtraEditors.MemoEdit txtNotifyTo;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage7;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private DevExpress.XtraEditors.CheckEdit chkMesAnterior;
        private DevExpress.XtraEditors.CalcEdit txtPrecioCompra;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.ToggleSwitch tglVentaConfig;
        private DevExpress.XtraEditors.ToggleSwitch tglCompraConfig;
        private Utils.ctrlProcessPurchase ctrlProcessPurchase;
        private Utils.ctrlProcessPurchase ctrlProcessSale;
        private DevExpress.XtraEditors.GroupControl groupControl4;
        public DevExpress.XtraEditors.SimpleButton simpleButton1;
        public DevExpress.XtraEditors.TextEdit txtSalePath;
        public DevExpress.XtraEditors.SimpleButton btnPath;
        public DevExpress.XtraEditors.TextEdit txtPurchasePath;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.TextEdit txtFilePurchaseOUT;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.TextEdit txtFileSaleOUT;
        private DevExpress.XtraEditors.CheckEdit chkBatch;
    }
}
﻿
namespace GasStationTools.Ventana
{
    partial class frmSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSupplier));
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.txtID = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtName = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtRFC = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.txtPermiso1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.txtPermiso2 = new DevExpress.XtraEditors.TextEdit();
            this.btnSaveServer = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.txtID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRFC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPermiso1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPermiso2.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(32, 46);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(17, 16);
            this.labelControl16.TabIndex = 28;
            this.labelControl16.Text = "ID:";
            // 
            // txtID
            // 
            this.txtID.EnterMoveNextControl = true;
            this.txtID.Location = new System.Drawing.Point(100, 43);
            this.txtID.Name = "txtID";
            this.txtID.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtID.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtID.Size = new System.Drawing.Size(100, 22);
            this.txtID.TabIndex = 27;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(32, 74);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(50, 16);
            this.labelControl1.TabIndex = 30;
            this.labelControl1.Text = "Nombre:";
            // 
            // txtName
            // 
            this.txtName.EnterMoveNextControl = true;
            this.txtName.Location = new System.Drawing.Point(100, 71);
            this.txtName.Name = "txtName";
            this.txtName.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtName.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtName.Size = new System.Drawing.Size(505, 22);
            this.txtName.TabIndex = 29;
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(32, 101);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(28, 16);
            this.labelControl2.TabIndex = 32;
            this.labelControl2.Text = "RFC:";
            // 
            // txtRFC
            // 
            this.txtRFC.EnterMoveNextControl = true;
            this.txtRFC.Location = new System.Drawing.Point(100, 98);
            this.txtRFC.Name = "txtRFC";
            this.txtRFC.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtRFC.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtRFC.Size = new System.Drawing.Size(147, 22);
            this.txtRFC.TabIndex = 31;
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(32, 128);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(62, 16);
            this.labelControl3.TabIndex = 34;
            this.labelControl3.Text = "Permiso 1:";
            // 
            // txtPermiso1
            // 
            this.txtPermiso1.EnterMoveNextControl = true;
            this.txtPermiso1.Location = new System.Drawing.Point(100, 125);
            this.txtPermiso1.Name = "txtPermiso1";
            this.txtPermiso1.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtPermiso1.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtPermiso1.Size = new System.Drawing.Size(190, 22);
            this.txtPermiso1.TabIndex = 33;
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(32, 156);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(62, 16);
            this.labelControl4.TabIndex = 36;
            this.labelControl4.Text = "Permiso 2:";
            // 
            // txtPermiso2
            // 
            this.txtPermiso2.EnterMoveNextControl = true;
            this.txtPermiso2.Location = new System.Drawing.Point(100, 153);
            this.txtPermiso2.Name = "txtPermiso2";
            this.txtPermiso2.Properties.AppearanceFocused.BackColor = System.Drawing.SystemColors.Info;
            this.txtPermiso2.Properties.AppearanceFocused.Options.UseBackColor = true;
            this.txtPermiso2.Size = new System.Drawing.Size(190, 22);
            this.txtPermiso2.TabIndex = 35;
            // 
            // btnSaveServer
            // 
            this.btnSaveServer.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnSaveServer.Image = ((System.Drawing.Image)(resources.GetObject("btnSaveServer.Image")));
            this.btnSaveServer.Location = new System.Drawing.Point(331, 114);
            this.btnSaveServer.Name = "btnSaveServer";
            this.btnSaveServer.Size = new System.Drawing.Size(159, 61);
            this.btnSaveServer.TabIndex = 37;
            this.btnSaveServer.Text = "Grabar cambios";
            this.btnSaveServer.ToolTip = "Salvar los cambios de la configuración del servidor seleccionado.";
            this.btnSaveServer.Click += new System.EventHandler(this.btnSaveServer_Click);
            // 
            // simpleButton1
            // 
            this.simpleButton1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.simpleButton1.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton1.Image")));
            this.simpleButton1.Location = new System.Drawing.Point(496, 128);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(99, 47);
            this.simpleButton1.TabIndex = 38;
            this.simpleButton1.Text = "Cerrar";
            this.simpleButton1.ToolTip = "Salvar los cambios de la configuración del servidor seleccionado.";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // frmSupplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 195);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.btnSaveServer);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.txtPermiso2);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.txtPermiso1);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.txtRFC);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.txtID);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSupplier";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Proveedores";
            ((System.ComponentModel.ISupportInitialize)(this.txtID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtRFC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPermiso1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPermiso2.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.SimpleButton btnSaveServer;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        public DevExpress.XtraEditors.TextEdit txtID;
        public DevExpress.XtraEditors.TextEdit txtName;
        public DevExpress.XtraEditors.TextEdit txtRFC;
        public DevExpress.XtraEditors.TextEdit txtPermiso1;
        public DevExpress.XtraEditors.TextEdit txtPermiso2;
    }
}
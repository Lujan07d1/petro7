﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
using GasStationTools.Logica;
using System.IO;
using Newtonsoft.Json;
using GasStationTools.Utils;
using GasStationTools;

namespace GasStationTools.Ventanas
{
    public partial class frmConfig : DevExpress.XtraEditors.XtraForm
    {
        const String SERVER_CONFIG = "config.server.json";
        const String PROCESS_CONFIG = "config.process.json";
        const String SUPPLIER_CONFIG = "config.supplier.json";
        const String SYSTEM_CONFIG = "config.system.json";
        const String NOTIFICATION_CONFIG = "config.notification.json";

        const int SERVER = 1;
        const int PROCESS = 2;
        const int SUPPLIER = 3;
        const int SYSTEM = 4;
        const int NOTIFICATION = 5;

        const String myIniFile = "\\p7_automation_json.ini";
        private String file_log;

        private bool changeServer = false;
        private bool changeProcess = false;
        private bool changeSupplier = false;
        private bool changeSystem = false;


        private List<Root_Server> servers;
        private List<Root_Process> process;
        private List<Root_Supplier> suppliers;
        private List<Root_Config> system;

        private IniConfiguration ini;
        private cls_json_config json_config;
        private cls_common_task.procesarArchivos log;
        private DataTable logProcesado;
        private cls_smtp_config_send_mail mailServer;
        
        public frmConfig()
        {
            InitializeComponent();

            var myFile = Path.GetDirectoryName(Application.ExecutablePath);
            myFile += myIniFile;
            ini = new IniConfiguration(myFile);

            file_log = string.Format(@"{0}\{1}", Path.GetDirectoryName(Application.ExecutablePath), ini.generate_json_log);
            log = new cls_common_task.procesarArchivos(file_log);
            logProcesado = log.CrearTable("myLog");

            json_config = new cls_json_config();      
        }

        private void frmConfig_Load(object sender, EventArgs e)
        {
            try
            {
                checkInitialConfig();
                deserializeandDecodeConfig();

                lueServer.Properties.DataSource = servers;                
                luePlataforma.Properties.DataSource = servers;

                gcSupplier.DataSource = suppliers;

                // Control Process/Tasks
                setProcessTask(ctrlProcessStation, pageStation.Tag.ToString());
                setProcessTask(ctrlProcessSupplier, pageSupplier.Tag.ToString());

                setProcessTaskPlus(ctrlProcessPurchase, pagePurchase.Tag.ToString());
                setProcessTaskPlus(ctrlProcessSale, pageSale.Tag.ToString());

                loadLog();
                loadSystem();
            }


            catch (Exception ex)
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Error {0} ", ex.Message));
                if (system[0].software_crash_log) send_log_process(logProcesado, "Panel de control");
            }
            finally
            {

                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", "Finaliza proceso "));
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", ""));

                log.asignarDataTable(logProcesado);
                log.archivosProcesados();
            }
        }

        private void checkInitialConfig()
        {
            // Checar/crear archivos JSON
            string path;

            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> {0} ", ini.generate_json_exe));
            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Inicia Configuración de Automatización");
            path = string.Format(@"{0}\{1}", ini.generate_json_exe_path, SERVER_CONFIG);
            if (!File.Exists(path))
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Crea configuración servidores...{0} ", SERVER_CONFIG));
                json_config.CreateJsonConfig(path, SERVER);
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Termina configuración servidores...{0} ", ""));

            }
            else
            {                
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Leyendo configuración para servidores");
            }

            path = string.Format(@"{0}\{1}", ini.generate_json_exe_path, PROCESS_CONFIG);
            if (!File.Exists(path))
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Crea configuración procesos...{0} ", PROCESS_CONFIG));
                json_config.CreateJsonConfig(path, PROCESS);
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Termina configuración procesos...{0} ", ""));
            }
            else
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Leyendo configuración para procesos");                
            }

            path = string.Format(@"{0}\{1}", ini.generate_json_exe_path, SUPPLIER_CONFIG);
            if (!File.Exists(path))
            {                
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Crea configuración proveedores...{0} ", SUPPLIER_CONFIG));
                json_config.CreateJsonConfig(path, SUPPLIER);
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Termina configuración proveedores...{0} ", ""));

            }
            else
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Leyendo configuración para proveedores");
            }

            path = string.Format(@"{0}\{1}", ini.generate_json_exe_path, SYSTEM_CONFIG);
            if (!File.Exists(path))
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Crea configuración sistema...{0} ", SYSTEM_CONFIG));
                json_config.CreateJsonConfig(path, SYSTEM);
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Termina configuración sistema...{0} ", ""));

            }
            else
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Leyendo configuración para sistema");
            }

        }

        private void deserializeandDecodeConfig()
        {
            string path = "";

            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Inicia deserialización y desencriptado");


            path = string.Format(@"{0}{1}", ini.generate_json_exe_path, SYSTEM_CONFIG);
            if (!File.Exists(path))
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Error leyendo configuración de sistema...{0} ", SYSTEM_CONFIG));
            }
            else
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Objeto sistema");
                system = json_config.DeserializeConfig(path);
            }

            path = string.Format(@"{0}{1}", ini.generate_json_exe_path, SERVER_CONFIG);
            if (!File.Exists(path))
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Error leyendo configuración de servidores...{0} ", SERVER_CONFIG));
            }
            else
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Objeto servidores");
                servers = json_config.DeserializeServer(path);
            }

            path = string.Format(@"{0}{1}", ini.generate_json_exe_path, PROCESS_CONFIG);
            if (!File.Exists(path))
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Error leyendo configuración de procesos...{0} ", PROCESS_CONFIG));
            }
            else
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Objeto procesos");
                process = json_config.DeserializeProcess(path);
            }

            path = string.Format(@"{0}{1}", ini.generate_json_exe_path, SUPPLIER_CONFIG);
            if (!File.Exists(path))
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Error leyendo configuración de proveedores...{0} ", SUPPLIER_CONFIG));
            }
            else
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Objeto proveedores");
                suppliers = json_config.DeserializeSupplier(path);
            }      

            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), string.Format(" --> Termina configuración de Objetos", ""));
        }

        private void setProcessTask(ctrlProcess myControl, string source)
        {
            // Aplicar los cambios en el objeto de Servidores.
            var indexOf = process.IndexOf(process.Find(p => p.source == source));

            myControl.lueServer.Properties.DataSource = servers;

            if (process[indexOf].configuration.datasource == "query")
                myControl.tglSource.IsOn = true;
            else
                myControl.tglSource.IsOn = false;

            myControl.getsetLog = new DataTable();

            myControl.txtPath.EditValue = @process[indexOf].configuration.path;
            myControl.txtPrefix.Text = process[indexOf].configuration.prefix;
            myControl.txtExtension.Text = process[indexOf].configuration.extension;
            myControl.txtQuery.Text = process[indexOf].configuration.query_in;
            myControl.lueServer.EditValue = process[indexOf].configuration.server_in;
            myControl.txtColumns.Text = process[indexOf].configuration.columns;
            myControl.changeProcess = false;
        }

        private void setProcessTaskPlus(ctrlProcessPurchase myControl, string source)
        {
            // Aplicar los cambios en el objeto de Servidores.
            var indexOf = process.IndexOf(process.Find(p => p.source == source));

            myControl.lueServerIN.Properties.DataSource = servers;
            myControl.lueServerOut.Properties.DataSource = servers;

            if (process[indexOf].configuration.datasource == "query")
                myControl.tglSource.IsOn = true;
            else
                myControl.tglSource.IsOn = false;

            myControl.getsetLog = new DataTable();

            myControl.txtPath.EditValue = @process[indexOf].configuration.path;
            myControl.txtPrefix.Text = process[indexOf].configuration.prefix;
            myControl.txtExtension.Text = process[indexOf].configuration.extension;
            myControl.txtQueryIN.Text = process[indexOf].configuration.query_in;
            myControl.lueServerIN.EditValue = process[indexOf].configuration.server_in;

            myControl.txtQueryOut.Text = process[indexOf].configuration.query_out;
            myControl.lueServerOut.EditValue = process[indexOf].configuration.server_out;

            myControl.txtColumns.Text = process[indexOf].configuration.columns;
            myControl.changeProcess = false;
        }
        

        private void labelControl1_Click(object sender, EventArgs e)
        {

        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {

        }

        private void labelControl5_Click(object sender, EventArgs e)
        {

        }

        private void panelControl4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void labelControl9_Click(object sender, EventArgs e)
        {

        }

        private void btnTestConection_Click(object sender, EventArgs e)
        {
            string bddSwitch = luePlataforma.EditValue.ToString();

            string server = txtIP.EditValue.ToString();
            string bdd = txtDatabase.EditValue.ToString();
            string user = txtUsername.EditValue.ToString();
            string pass = txtPassword.EditValue.ToString();
            string plus = txtConfigPlus.EditValue.ToString();

            logProcesado.Rows.Clear();
            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Probando conexión {0}", bddSwitch ));

            switch (bddSwitch)
            {
                case "SQL":
                {
                    try
                    {
                            
                        using (Ado.cls_connection_sql sql = new Ado.cls_connection_sql(user, pass, server, 1433, bdd, plus))
                        {
                            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> conexión exitosa");
                            MessageBox.Show("Prueba de conexión exitosa");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(String.Format("Error conectando con la base de datos, revise los parametros {0}", ex.Message), "Error");
                        logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Prueba fallida: {0}", ex.Message));
                    }
                    finally
                    {

                    }
                        
                    break;
                }
                case "ORACLE":
                {
                    try
                    {
                        using (Ado.cls_connection_oracle sql = new Ado.cls_connection_oracle(user, pass, server, 1521, bdd, plus))
                        {
                            MessageBox.Show("Prueba de conexión exitosa");
                            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> conexión exitosa");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(String.Format("Error conectando con la base de datos, revise los parametros {0}", ex.Message), "Error");
                        logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Prueba fallida: {0}", ex.Message));
                    }
                    finally
                    {
                          
                    }
                    break;
                }
                case "POSTGRESQL":
                {
                    try
                    {
                        using (Ado.cls_connection_postgresql sql = new Ado.cls_connection_postgresql(user, pass, server, 5432, bdd, plus))
                        {
                            MessageBox.Show("Prueba de conexión exitosa");
                            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> conexión exitosa");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(String.Format("Error conectando con la base de datos, revise los parametros {0}", ex.Message), "Error");
                        logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Prueba fallida: {0}", ex.Message));
                    }
                    finally
                    {
                          
                    }
                    break;
                }
                default:
                {
                    MessageBox.Show("Esta plataforma no está configurada, solicite que sea agregada.");
                    logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> Plataforma desconocida");
                   
                    break;
                }
            }

            logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> ");
            log.asignarDataTable(logProcesado);
            log.archivosProcesados();
        }

        private void lueServer_EditValueChanged(object sender, EventArgs e)
        {
            var including = new string[] { lueServer.EditValue.ToString() };
            var filteredServer = servers.Where(servers => servers.description.Contains(lueServer.EditValue.ToString()));
            foreach (Root_Server selectedserver in filteredServer)
            {
                txtIP.EditValue = selectedserver.server.ip_address;
                txtDatabase.EditValue = selectedserver.server.default_database;
                txtUsername.EditValue = selectedserver.server.user_id;
                txtPassword.EditValue = selectedserver.server.password;
                luePlataforma.EditValue = selectedserver.platform;
                txtConfigPlus.EditValue = selectedserver.server.config_plus;
            }           
            
        }

        private void labelControl16_Click(object sender, EventArgs e)
        {

        }

        private void labelControl17_Click(object sender, EventArgs e)
        {

        }

        private void txtConfirmPassword_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void txtConfirmPassword_Leave(object sender, EventArgs e)
        {
          

        }

        private void btnSaveServer_Click(object sender, EventArgs e)
        {
            if (txtPassword.EditValue.ToString() != txtConfirmPassword.Text.ToString())
            {
                txtPassword.SelectAll();
                txtPassword.Focus();
                lblPass.Text = "* Las contraseñas no coinciden";
            }
            else
            {
                lblPass.Text = "";

                var indexOf = servers.IndexOf(servers.Find(p => p.description == lueServer.EditValue.ToString()));

                // Aplicar los cambios en el objeto de Servidores.
                servers[indexOf].server.ip_address = txtIP.EditValue.ToString();
                servers[indexOf].server.default_database = txtDatabase.EditValue.ToString();
                servers[indexOf].server.user_id = txtUsername.EditValue.ToString();
                servers[indexOf].server.password = txtConfirmPassword.EditValue.ToString();

                servers[indexOf].server.config_plus = txtConfigPlus.EditValue.ToString();
                servers[indexOf].platform = luePlataforma.EditValue.ToString();

                changeServer = true;
            }
        }

        private void frmConfig_FormClosing(object sender, FormClosingEventArgs e)
        {
            xtraTabControl1_SelectedPageChanged(null, null);
            if (system[0].change_config_log) send_log_process(logProcesado, "Panel de control", "", "");

        }

        private void xtraTabControl1_SelectedPageChanged(object sender, DevExpress.XtraTab.TabPageChangedEventArgs e)
        {
            if (changeServer)
            {
                changeServer = false;
                changeConfigServer();               
            }
            // Procesos
            if (ctrlProcessStation.changeProcess) changeProcess = ctrlProcessStation.changeProcess;
            if (ctrlProcessSupplier.changeProcess) changeProcess = ctrlProcessSupplier.changeProcess;
            if (ctrlProcessPurchase.changeProcess) changeProcess = ctrlProcessPurchase.changeProcess;
            if (ctrlProcessSale.changeProcess) changeProcess = ctrlProcessSale.changeProcess;

            if (changeProcess)
            {
                changeProcess = false;
                changeConfigProcess();
            }

            if (changeSupplier)
            {
                changeSupplier = false;
                changeConfigSupplier();
            }

            if (changeSystem)
            {
                changeSystem = false;
                changeConfigSystem();
            }

        }

        private void changeConfigServer()
        {
            try
            {

                logProcesado.Rows.Clear();
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Salvando cambios en configuración de servidores {0}", ""));

                servers.ForEach(c => c.description = StringCipher.Encrypt(c.description, true));
                servers.ForEach(c => c.platform = StringCipher.Encrypt(c.platform, true));
                servers.ForEach(c => c.server.ip_address = StringCipher.Encrypt(c.server.ip_address, true));
                servers.ForEach(c => c.server.default_database = StringCipher.Encrypt(c.server.default_database, true));
                servers.ForEach(c => c.server.user_id = StringCipher.Encrypt(c.server.user_id, true));
                servers.ForEach(c => c.server.password = StringCipher.Encrypt(c.server.password, true));
                servers.ForEach(c => c.server.config_plus = StringCipher.Encrypt(c.server.config_plus, true));

                JsonSerializer serializer = new JsonSerializer();

                var path = string.Format(@"{0}\{1}", ini.generate_json_exe_path, SERVER_CONFIG);

                using (StreamWriter sw = new StreamWriter(path))
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    serializer.Serialize(writer, servers);
                }

            }
            catch (Exception ex)
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Error registrando cambios en configuración de servidores{0} ", ex.Message));
            }
            finally
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> ");
                log.asignarDataTable(logProcesado);
                log.archivosProcesados();
            }
        }
        private void changeConfigProcess()
        {
            try
            {

                logProcesado.Rows.Clear();
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Salvando cambios en configuración de procesos {0}", ""));

                if (ctrlProcessStation.changeProcess)
                {                    
                    logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Salvando cambios en configuración de procesos | {0}", "Estaciones"));
                    getProcessTask(ctrlProcessStation, pageStation.Tag.ToString());                  
                }

                if (ctrlProcessSupplier.changeProcess)
                {
                    logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Salvando cambios en configuración de procesos | {0}", "Proveedores"));
                    getProcessTask(ctrlProcessSupplier, pageSupplier.Tag.ToString());                   
                }

                if (ctrlProcessPurchase.changeProcess)
                {
                    logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Salvando cambios en configuración de procesos | {0}", "Compras"));
                    getProcessTaskPlus(ctrlProcessPurchase, pagePurchase.Tag.ToString());                   
                }

                if (ctrlProcessSale.changeProcess)
                {
                    logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Salvando cambios en configuración de procesos | {0}", "Ventas"));
                    getProcessTaskPlus(ctrlProcessSale, pageSale.Tag.ToString());                   
                }


                process.ForEach(c => c.source = StringCipher.Encrypt(c.source, true));
                process.ForEach(c => c.configuration.server_in = StringCipher.Encrypt(c.configuration.server_in, true));
                process.ForEach(c => c.configuration.query_in = StringCipher.Encrypt(c.configuration.query_in, true));
                process.ForEach(c => c.configuration.prefix = StringCipher.Encrypt(c.configuration.prefix, true));
                process.ForEach(c => c.configuration.path = StringCipher.Encrypt(c.configuration.path, true));
                process.ForEach(c => c.configuration.extension = StringCipher.Encrypt(c.configuration.extension, true));
                process.ForEach(c => c.configuration.columns = StringCipher.Encrypt(c.configuration.columns, true));
                process.ForEach(c => c.configuration.datasource = StringCipher.Encrypt(c.configuration.datasource, true));
                process.ForEach(c => c.configuration.server_out = StringCipher.Encrypt(c.configuration.server_out, true));
                process.ForEach(c => c.configuration.query_out = StringCipher.Encrypt(c.configuration.query_out, true));

                JsonSerializer serializer = new JsonSerializer();

                var path = string.Format(@"{0}\{1}", ini.generate_json_exe_path, PROCESS_CONFIG);

                using (StreamWriter sw = new StreamWriter(path))
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    serializer.Serialize(writer, process);
                }

            }
            catch (Exception ex)
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Error registrando cambios en configuración de procesos {0} ", ex.Message));
            }
            finally
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> ");
                log.asignarDataTable(logProcesado);
                log.archivosProcesados();
            }
        }
        private void changeConfigSupplier()
        {
            try
            {
                logProcesado.Rows.Clear();
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Salvando cambios en configuración de proveedores {0}", ""));
                
                suppliers.ForEach(c => c.nombre = StringCipher.Encrypt(c.nombre, true));
                suppliers.ForEach(c => c.rfc = StringCipher.Encrypt(c.rfc, true));
                suppliers.ForEach(c => c.permiso1 = StringCipher.Encrypt(c.permiso1, true));
                suppliers.ForEach(c => c.permiso2 = StringCipher.Encrypt(c.permiso2, true));

                JsonSerializer serializer = new JsonSerializer();

                var path = string.Format(@"{0}\{1}", ini.generate_json_exe_path, SUPPLIER_CONFIG);

                using (StreamWriter sw = new StreamWriter(path))
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    serializer.Serialize(writer, suppliers);
                }

            }
            catch (Exception ex)
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Error registrando cambios en configuración de proveedores {0} ", ex.Message));
            }
            finally
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> ");
                log.asignarDataTable(logProcesado);
                log.archivosProcesados();
            }
        }
        private void changeConfigSystem()
        {
            try
            {

                logProcesado.Rows.Clear();
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Salvando cambios en configuración de sistema {0}", ""));

                system.ForEach(c => c.server= StringCipher.Encrypt(c.server, true));
                system.ForEach(c => c.username = StringCipher.Encrypt(c.username, true));
                system.ForEach(c => c.password = StringCipher.Encrypt(c.password, true));
                system.ForEach(c => c.port = StringCipher.Encrypt(c.port, true));
                system.ForEach(c => c.timeout = StringCipher.Encrypt(c.timeout, true));
                system.ForEach(c => c.notify_to = StringCipher.Encrypt(c.notify_to, true));

                system.ForEach(c => c.purchase_output_path = StringCipher.Encrypt(c.purchase_output_path, true));
                system.ForEach(c => c.sale_output_path = StringCipher.Encrypt(c.sale_output_path, true));
                system.ForEach(c => c.purchase_output = StringCipher.Encrypt(c.purchase_output, true));
                system.ForEach(c => c.sale_output = StringCipher.Encrypt(c.sale_output, true));

                JsonSerializer serializer = new JsonSerializer();

                var path = string.Format(@"{0}\{1}", ini.generate_json_exe_path, SYSTEM_CONFIG);

                using (StreamWriter sw = new StreamWriter(path))
                using (JsonWriter writer = new JsonTextWriter(sw))
                {
                    serializer.Serialize(writer, system);
                }

            }
            catch (Exception ex)
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Error registrando cambios en configuración de sistema {0} ", ex.Message));
            }
            finally
            {
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> ");
                log.asignarDataTable(logProcesado);
                log.archivosProcesados();
            }
        }

        private void loadLog()
        {
            if (File.Exists(file_log))
            {
                string log = String.Empty;
                DateTime dt = File.GetLastWriteTime(file_log);
                lblModify.Text = dt.ToString();

                log = File.ReadAllText(file_log);
                txtLog.Properties.WordWrap = false;
                txtLog.EditValue = log;
            }
        }

        private void loadSystem()
        {
            txtSMTP.Text = system[0].server;
            txtSMTPUser.Text = system[0].username;
            txtSMPTPass.Text = system[0].password;
            txtTimeout.Text = system[0].timeout;
            txtNotifyTo.Text = system[0].notify_to;
            txtPort.Text = system[0].port;

            chkSSL.Checked = system[0].ssl;
            chkConfig.Checked = system[0].change_config_log;
            chkAllLog.Checked = system[0].all_activity_log;
            chkCrash.Checked = system[0].software_crash_log;

            chkMesAnterior.Checked = system[0].only_lastmonth;
            txtPrecioCompra.Text = system[0].max_purchase_price.ToString();
            tglCompraConfig.IsOn = system[0].purchase_output_file;
            tglVentaConfig.IsOn = system[0].sale_output_file;

            chkBatch.Checked =system[0].batch_file;
            txtFilePurchaseOUT.Text = system[0].purchase_output;
            txtFileSaleOUT.Text = system[0].sale_output;
            txtPurchasePath.Text = system[0].purchase_output_path;
            txtSalePath.Text = system[0].sale_output_path;
        }

        private void copyLog(DataTable source, DataTable target)
        {            
            foreach (DataRow dr in source.Rows)
            {
                target.Rows.Add(dr.ItemArray);
            }
        }

        private void getProcessTask(ctrlProcess myControl, string source)
        {
            copyLog(myControl.getsetLog, logProcesado);

            var indexOf = process.IndexOf(process.Find(p => p.source == source));

            if (myControl.tglSource.IsOn) process[indexOf].configuration.datasource = "query";
            else process[indexOf].configuration.datasource = "file";

            process[indexOf].configuration.path = myControl.txtPath.EditValue.ToString();
            process[indexOf].configuration.prefix = myControl.txtPrefix.Text;
            process[indexOf].configuration.extension = myControl.txtExtension.Text;
            process[indexOf].configuration.query_in = myControl.txtQuery.Text;
            process[indexOf].configuration.server_in = myControl.lueServer.EditValue.ToString();
            process[indexOf].configuration.columns = myControl.txtColumns.Text;
            myControl.changeProcess = false;

        }

        private void getProcessTaskPlus(ctrlProcessPurchase myControl, string source)
        {
            copyLog(myControl.getsetLog, logProcesado);

            var indexOf = process.IndexOf(process.Find(p => p.source == source));

            if (myControl.tglSource.IsOn) process[indexOf].configuration.datasource = "query";
            else process[indexOf].configuration.datasource = "file";

            process[indexOf].configuration.path = myControl.txtPath.EditValue.ToString();
            process[indexOf].configuration.prefix = myControl.txtPrefix.Text;
            process[indexOf].configuration.extension = myControl.txtExtension.Text;
            process[indexOf].configuration.query_in = myControl.txtQueryIN.Text;
            process[indexOf].configuration.server_in = myControl.lueServerIN.EditValue.ToString();
            process[indexOf].configuration.query_out = myControl.txtQueryOut.Text;
            process[indexOf].configuration.server_out = myControl.lueServerOut.EditValue.ToString();

            process[indexOf].configuration.columns = myControl.txtColumns.Text;
            myControl.changeProcess = false;

        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            Ventana.frmSupplier supplier = new Ventana.frmSupplier();
            supplier.ShowDialog();
            if (supplier.DialogResult == DialogResult.OK)
            {
                logProcesado.Rows.Clear();
                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> Agregando proveedor para configuración de Compras {0}", ""));

                changeSupplier = true;
                suppliers.Add(new Root_Supplier { id = Convert.ToInt32(supplier.txtID.Text.ToString()),
                    nombre = supplier.txtName.Text.ToString(),
                    rfc = supplier.txtRFC.Text.ToString(),
                    permiso1 = supplier.txtPermiso1.Text.ToString(),
                    permiso2 = supplier.txtPermiso2.Text.ToString()
                });

                gcSupplier.RefreshDataSource();

                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), String.Format(" --> [{0}{1}{2}{3}{4}]", 
                    supplier.txtID.Text.ToString(), supplier.txtName.Text.ToString(), supplier.txtRFC.Text.ToString(),
                    supplier.txtPermiso1.Text.ToString(), supplier.txtPermiso2.Text.ToString()));

                logProcesado.Rows.Add(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), " --> ");
                log.asignarDataTable(logProcesado);
                log.archivosProcesados();
            }

        }

        private void labelControl4_Click(object sender, EventArgs e)
        {

        }

        private void btnRefreshLog_Click(object sender, EventArgs e)
        {
            loadLog();
        }

        private void txtTimeout_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void txtTimeout_EditValueChanged_1(object sender, EventArgs e)
        {

        }

        private void btnTestSMTP_Click(object sender, EventArgs e)
        {
            mailServer = new cls_smtp_config_send_mail(txtSMTP.Text.ToString(), Convert.ToInt32(txtPort.Text.ToString()),
                chkSSL.Checked, Convert.ToInt32(txtTimeout.Text.ToString()), txtSMTPUser.Text.ToString(), txtSMPTPass.Text.ToString());
            try
            {
                mailServer.send_mail(txtMailTest.Text.ToString(), "Prueba Automatización JSON P7", "Este es un correo de prueba, P7", "Automatización Json");
                MessageBox.Show("Prueba realizada correctamente", "GasStationTools");
            }
            catch (Exception ex)
            {
                MessageBox.Show(String.Format("Error enviando correo de prueba, revise configuración [{0}]", ex.Message));
            }
        }

        private void btnChangeSystem_Click(object sender, EventArgs e)
        {
            changeSystem = true;

            system[0].server = txtSMTP.Text;
            system[0].username = txtSMTPUser.Text;
            system[0].password = txtSMPTPass.Text;
            system[0].timeout = txtTimeout.Text;
            system[0].notify_to = txtNotifyTo.Text;
            system[0].port = txtPort.Text;

            system[0].ssl = chkSSL.Checked;
            system[0].change_config_log = chkConfig.Checked;
            system[0].all_activity_log = chkAllLog.Checked;
            system[0].software_crash_log = chkCrash.Checked;

            system[0].only_lastmonth = chkMesAnterior.Checked;
            system[0].max_purchase_price = Convert.ToDouble(txtPrecioCompra.Text);
            system[0].purchase_output_file = tglCompraConfig.IsOn;
            system[0].sale_output_file = tglVentaConfig.IsOn;

            system[0].batch_file = chkBatch.Checked;
            system[0].purchase_output_path = txtPurchasePath.Text;
            system[0].sale_output_path = txtSalePath.Text;
            system[0].purchase_output = txtFilePurchaseOUT.Text;
            system[0].sale_output = txtFileSaleOUT.Text;
        }

        private void send_log_process(DataTable log, string action, string title = "error detectado en", string msg = "Se ha detectado un error en el proceso de ")
        {
            cls_smtp_config_send_mail sendLog = new cls_smtp_config_send_mail(txtSMTP.Text, Convert.ToInt32(txtPort.Text), chkSSL.Checked, Convert.ToInt32(txtTimeout.Text), txtSMTPUser.Text, txtSMPTPass.Text);

            string body = string.Empty;
            string subject = String.Format("Automatización JSON, {1} {0}", action, title);

            foreach (DataRow row in log.Rows)
            {
                body += string.Format("{0}|{1}{2}", row["Date"], row["Message"], "<br>");
            }

            body = string.Format("<b>{2}AUTOMATIZACIÓN JSON</b>{1}Revise los archivos de configuración{1}{1}{1}{0}{1}{1}<b>Equipo TI de Petro7</b>", body, "<br>", msg);
            sendLog.send_mail(txtNotifyTo.Text, subject, body, "GasStationTools");
        }

        private void ctrlProcessPurchase_Load(object sender, EventArgs e)
        {

        }

        private void tglCompraConfig_Toggled(object sender, EventArgs e)
        {
            txtPurchasePath.Enabled = !tglCompraConfig.IsOn; 
            txtFilePurchaseOUT.Enabled = !tglCompraConfig.IsOn;
            chkBatch.Enabled = txtFilePurchaseOUT.Enabled;
        }

        private void tglVentaConfig_Toggled(object sender, EventArgs e)
        {
            txtFileSaleOUT.Enabled = !tglVentaConfig.IsOn;
            txtSalePath.Enabled = !tglVentaConfig.IsOn;
            chkBatch.Enabled = txtSalePath.Enabled;
        }
    }
}
IF OBJECT_ID('tempdb..#TEMP_CAT_PROV') IS NOT NULL
BEGIN
	DROP TABLE #TEMP_CAT_PROV
END

CREATE TABLE #TEMP_CAT_PROV(
ID NUMERIC(18,0)
,NOMBRE VARCHAR(150)
,RFC VARCHAR(20)
,PERMISO1 VARCHAR(50)
,PERMISO2 VARCHAR(50))


INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (15322,'PEMEX TRANSFORMACI�N INDUSTRIAL','PTI151101TE5','PL/10537/TRA/OM/2015','H/9857/COM/2015')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (19043,'DISTRIBUIDORA DAGAL S. A. DE C. V.','DDA940608NX1','','H/22036/COM/2018')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (18362,'VALORES ABC S.A. DE C.V.','VAB9403181Y5','','H/19724/COM/2016')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (17484,'VITOL MARKETING MEXICO S. DE R.L. DE C.V','VMM1608034M7','PL/21924/TRA/OM/2018','H/20392/COM/2017')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (17898,'NOVUM MEXICO TRADING S DE RL DE CV','NMT160307MZ0','PL/11175/TRA/OM/2015','H/19477/COM/2016')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (19450,'ABASTECEDORA DE COMBUSTIBLES DEL PAC�FICO, S. A. DE C. V.','ACP000726NG7','N/A','H/11771/COM/2015')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (3508,'TRANSPORTES ESPECIALIZADOS SAN ROBERTO','TSE000322P5A','PL/18969/TRA/OM/2016','N/A')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (15992,'TRAREYSA, S.A. DE C.V.','TRA021112CD0','PL/13704/TRA/OM/2016','N/A')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (19192,'COMERCIALIZADORA Y DISTRIBUIDORA MARTINEZ Y MARTINEZ S.A. DE C.V.','CDM9801154V3','PL/13211/TRA/OM/2016','H/19952/COM/2017')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (19685,'ExxonMobil Mexico S.A. de C.V.','EME970101A45','N/A','H/20319/COM/2017')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (19638,'Transportaci�n Carretera S.A. de C.V.','TCA980629FC6','PL/18811/TRA/OM/2016','N/A')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (19672,'TRANSPORTES CEPSA SA DE CV','TCE900917RU3','PL/10480/TRA/OM/2015','N/A')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (20054,'GRUPO GAZPRO, S.A. DE C.V.','GGA1506117K7','N/A','H/21414/COM/2018')
INSERT INTO #TEMP_CAT_PROV (ID,NOMBRE,RFC,PERMISO1,PERMISO2) VALUES (21055,'MGC MEXICO S.A. DE C.V.','MME141110IJ9','N/A','H/10376/COM/2015')

GOTO Paso_1

Paso_2:

 /*Detalle de Recepcion de combustible*/
	select --g.gasStationID "#ES_AR"
		  g.posGasStationID NUMESTACION
		  ,tmp.UUID
		  ,'INGRESO' TIPO
		  ,CONVERT(DATETIME,tmp.fecha_timbrado) FECHAYHORATRANSACCION
		  ,CONVERT(DATE,fr.documentDate) FECHA
		 -- ,g.gasStationName ESTACION
		  ,fr.externalDocumentNumber NUMERODEREMISION
		   --,CONVERT(VARCHAR,jc.businessDate,103)+'-P'+CONVERT(vARCHAR,jc.zone)+'-C'+CONVERT(vARCHAR,jc.shift) LIQUIDACION
		  ,CASE fpr.extendedDescription 
			WHEN 'DIESEL' THEN 90
			WHEN 'MAGNA' THEN 95 
			WHEN 'PREMIUM' THEN 97 
			ELSE 0
		   END CODPROD
		  ,fpr.extendedDescription PRODUCTO
		  ,fprl.quantity VOLUMENFACTURADO
		  ,fprl.quantityat15degrees QTY15
		  ,fprl.receptionreference DESCARGA
		  ,ROW_NUMBER ( )   
			 OVER (PARTITION BY tmp.UUID ORDER BY  fr.fuelProductReceptionDate) LINEAOPER
		  --,fprl.realquantity DESCARGA
		  --,fr.auditRecordDate FECHA_ARCADIA
		  --,s.posSupplierID ID_PROV
		  ,s.supplierCompanyName NOMBRECLIENTE
		  ,tmpp.RFC
		  ,tmpp.PERMISO2  PERMISO
		  --,s2.posSupplierID ID_TRANSP
		  --,s2.supplierCompanyName TRANSPORTISTA
		  --,frtl.transportcode PROD_TRANSP
		  --,frtl.freightamount FLETE
		  --,frtl.invoicenumber ALBARAN_TRANSP
		  --,frtl.invoicedate FECHA_FACTURA_TRANSP
		  --,emp.employeeid ID_EMPLEADO
		  --,emp.firstName+' '+emp.lastName EMPLEADO
		  --,fprl.amountunitaryamount UIMP
		  --,fprl.amounttotalamount IMP
		  ,tmp.TOTAL_FACTURA   TOTALFACTURA
		  ,fr.fuelProductReceptionDate FECHAOPER
		  ,tmp.PRECIO_COMPRA PRECIOCOMPRA
		  --,CONVERT(NUMERIC(18,4),CASE WHEN  mevl.amountunitaryacquisition < 9 OR mevl.amountunitaryacquisition > 20 THEN CASE fprl.quantity WHEN 0 THEN 0 ELSE (tmp.TOTAL_FACTURA/1.16)/ fprl.quantity END
			--		ELSE mevl.amountunitaryacquisition END) PRECIOCOMPRA
		  --,fprl.*
		  --,s2.*
		  ,mevl.*
	from #TEMP_DATA_CFDI tmp 
		inner join fuelproductreception fr	on tmp.NUMERO_REMISION = fr.externalDocumentNumber
		inner join gasstation g on g.gasStationID = fr.store_gasStationID
		inner join merchandiseevent mev on mev.externalDocumentNumber = fr.externalDocumentNumber and mev.store_gasStationID = fr.store_gasStationID
		inner join merchandiseeventline mevl on mevl.merchandiseEvent_id = mev.id
		inner join supplier s on s.id = fr.supplier_id
		inner join fuelproductreceptionline fprl on fprl.merchandiseEventLineId = mevl.id
		inner join fuelproduct fpr on fpr.fuelProductID = fprl.fuelproduct_id
		LEFT JOIN #TEMP_CAT_PROV tmpp on tmpp.ID = CONVERT(NUMERIC(18,0),s.posSupplierID)
		--inner join journalClose jc on jc.journalCloseID = fr.journalClose_journalCloseID
		--inner join employee emp on emp.employeeid = fr.employee_employeeid
		--left join fuelreceptiontransportline frtl on frtl.fuelproductreceptionline_id = fprl.id
		--left join supplier s2 on s2.id = frtl.transportsupplier_id
	where 1=1
		--and g.posGasStationID = '6065'
		--and fr.externalDocumentNumber IN ('1628207','1628211')
		--and fr.externalDocumentNumber IN ('1106352')
		and mev.DTYPE = 'ITEMS_RECEPTION'
		and mev.unitOfMeasurePurpose = 'PURCHASE'
		and CONVERT(DATE,fr.documentDate) >= '$fecha_inicio' AND CONVERT(DATE,fr.documentDate) <= '$fecha_fin'
		--AND fprl.quantity = 0
	ORDER BY NUMESTACION,FECHAYHORATRANSACCION DESC,NUMERO_REMISION

	GOTO Final_Script

	
Paso_1:

IF OBJECT_ID('tempdb..#TEMP_DATA_CFDI') IS NOT NULL
BEGIN
	DROP TABLE #TEMP_DATA_CFDI
END

CREATE TABLE #TEMP_DATA_CFDI(
ESTACION NUMERIC(18,0)
,ID_PROVEEDOR NUMERIC(18,0)
,TOTAL_FACTURA NUMERIC(18,4)
,UUID VARCHAR(100)
,NUMERO_REMISION VARCHAR(50)
,FECHA_FACTURA DATETIME
,FECHA_TIMBRADO DATETIME
,PRECIO_COMPRA NUMERIC(18,4))

--BEGIN
--	$RAW_DATA

--END

GOTO Paso_2

Final_Script:


